# 🚀 COMPLETE PROMPT: AGT AFFILIATE TRAINING QUIZ APPLICATION

## PROJECT OVERVIEW

Build a full-stack web application for AGT (Absolute Genetic Technologies) affiliate training quiz system. This is a professional assessment tool where users take an 18-question multiple-choice quiz about AGT products and services, receive detailed performance analysis, and administrators can track all submissions.

**Target Platform:** Vercel
**Expected Traffic:** 70-80% mobile users
**Users:** End-users (taking quiz) + Admin (viewing submissions)

---

## TECHNICAL STACK

- **Framework:** Next.js 14+ with App Router
- **Language:** TypeScript (strict mode)
- **Styling:** Tailwind CSS
- **Database:** Vercel Postgres
- **Charts:** Recharts library
- **Email:** Resend API (100 free emails/day)
- **Authentication:** HTTP-only cookies + middleware
- **Deployment:** Vercel (zero-config)

---

## DESIGN SYSTEM

### Fonts
- **Headings/Buttons:** Montserrat, 600 weight
- **Body Text:** Inter, 400/500 weight

### Color Palette
```css
--primary-blue: #2AAFF5
--secondary-blue: #05087F
--excellent-tier: #2D5F3F
--good-tier: #4A9B6B
--pass-tier: #7BC79D
--need-improvement-tier: #ffc107
--text-primary: #212529
--text-secondary: #6c757d
--border-color: #dee2e6
--background-light: #f8f9fa
```

### Component Styling Standards
- Border radius: 8-12px
- Box shadow: `0 2px 8px rgba(0,0,0,0.1)`
- Input focus: Border color #2AAFF5, outline none
- Button hover: Darken by 10%
- Mobile-first responsive (breakpoints: 640px, 768px, 1024px, 1280px)

---

## DATABASE SCHEMA

### Table: `submissions`

```sql
CREATE TABLE submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  company VARCHAR(255) NOT NULL,
  position VARCHAR(255) NOT NULL,
  answers JSONB NOT NULL,
  score INTEGER NOT NULL,
  percentage DECIMAL(5,2) NOT NULL,
  tier VARCHAR(50) NOT NULL,
  category_scores JSONB NOT NULL,
  attempt_number INTEGER NOT NULL
);

CREATE INDEX idx_email ON submissions(email);
CREATE INDEX idx_timestamp ON submissions(timestamp);
CREATE INDEX idx_tier ON submissions(tier);
```

### JSONB Structure Examples

**answers field:**
```json
[
  { "questionId": 1, "selected": "B", "correct": true },
  { "questionId": 2, "selected": "B", "correct": false },
  ...
]
```

**category_scores field:**
```json
{
  "Product Knowledge": { "correct": 6, "total": 7 },
  "Operations & Procedures": { "correct": 2, "total": 3 },
  "Compliance & Privacy": { "correct": 2, "total": 2 },
  "Business & Sales": { "correct": 5, "total": 6 }
}
```

---

## QUIZ QUESTIONS (COPY WORD-FOR-WORD)

### Question 1
**Category:** Product Knowledge
**Question:** What is the core business or brand identity of Absolute Genetic Technologies (AGT), as primarily emphasized throughout the materials?
**Options:**
- A. A general technology firm specializing in bioinformatics analysis and data security compliance.
- B. A provider of specialized, science-backed, Asian-tailored DNA tests primarily focused on improving early childhood development (talent, nutrition, health, career) and secondarily offering wellness/career DNA tests for everyone.
- C. An internationally accredited laboratory based in Singapore dedicated solely to DNA extraction and genotyping procedures.
- D. A consultation service that helps customers save money by avoiding unnecessary spending on ineffective supplements and diets.
**Correct Answer:** B

### Question 2
**Category:** Product Knowledge
**Question:** What's not included inside the AGT DNA Test Kit?
**Options:**
- A. Greeting Card
- B. Gloves & facemask
- C. Registration Guide
- D. Buccal Swab
- E. Biohazard Ziplock Bag
**Correct Answer:** B

### Question 3
**Category:** Product Knowledge
**Question:** The Decode Talent DNA Test [Comprehensive] unlocks children's potential by analyzing a total of how many personal traits?
**Options:**
- A. 26 nutritional traits
- B. 42 health risk traits
- C. 50 personal traits
- D. 15 career development traits
**Correct Answer:** C

### Question 4
**Category:** Product Knowledge
**Question:** Which DNA test is described as unlocking optimal nutrition with a comprehensive genetic assessment on 26 nutritional traits, focusing on areas like appetite, brain, bone, digestive, energy, eye, and emotional health?
**Options:**
- A. Decode Talent DNA Test
- B. Decode Health DNA Test
- C. Decode Nutrition DNA Test
- D. Decode Career DNA Test
**Correct Answer:** C

### Question 5
**Category:** Product Knowledge
**Question:** The Decode Health DNA Test provides a comprehensive genetic analysis of up to 42 health risk traits. Of these traits, how many are specifically focused on different types of Cancers?
**Options:**
- A. 8
- B. 10
- C. 19
- D. 42
**Correct Answer:** C

### Question 6
**Category:** Operations & Procedures
**Question:** According to the pitching material on nurturing sports performance, which specific gene is mentioned as holding the answer for whether a child may be naturally inclined toward Sprint Sports?
**Options:**
- A. R577X gene
- B. ACTN3 gene
- C. Neuroticism gene
- D. ACTN4 gene
**Correct Answer:** B

### Question 7
**Category:** Operations & Procedures
**Question:** According to the DNA Sampling Procedures outlined in the training, what is the method utilized for the non-invasive saliva collection?
**Options:**
- A. Blood draw collection
- B. Hair sample collection
- C. Buccal Swab Collection
- D. Fingerprint analysis
**Correct Answer:** C

### Question 8
**Category:** Business & Sales
**Question:** What is the crucial element an affiliate must ensure is used by their customers to guarantee that the affiliate's commission will be issued?
**Options:**
- A. The customer must purchase the Child Development Bundle.
- B. The customer must use DuitNow as the payment option.
- C. The end-user must enter the promo code assigned to the affiliate during their purchase.
- D. The affiliate must register the test kit on the web app immediately after the sale.
**Correct Answer:** C

### Question 9
**Category:** Business & Sales
**Question:** When is the estimated time that the commission will be issued?
**Options:**
- A. Immediately after each sale
- B. By the end of each month
- C. By the 15th of each month
- D. At the start of the next month
**Correct Answer:** C

### Question 10
**Category:** Compliance & Privacy
**Question:** Which Malaysian Act is cited as the basis for keeping customer data safe in AGT's database under strict security protocols, ensuring data is not shared with third parties like insurance companies or employers?
**Options:**
- A. Financial Services Act 2013
- B. Companies Act 2016
- C. Personal Data Protection Act 2010 (PDPA)
- D. Communications and Multimedia Act 1998
**Correct Answer:** C

### Question 11
**Category:** Compliance & Privacy
**Question:** At AGT, your privacy is of the utmost importance to us and we are committed to protecting the privacy of all our users. To safeguard your data, we have implemented high standards of technology and operational security except:
**Options:**
- A. Anonymized Sample ID. Your sample receives a unique ID, keeping your information confidential and accessible only to authorized personnel.
- B. No Third-party Sharing. We never share, sell, or rent your data. You control how your information is used.
- C. Privacy by Design. Your genetic and personal data are stored separately in different, secure cloud systems following local and international standards for maximum protection.
- D. Affiliate Special Access. Data may be shared with affiliated companies for marketing purposes upon request.
**Correct Answer:** D

### Question 12
**Category:** Business & Sales
**Question:** The Decode Career DNA Test assesses a combination of traits focusing on Big 5 Personality traits and what other factors?
**Options:**
- A. Health risk traits
- B. 10 inborn aptitudes
- C. Overall Wellness traits
- D. Nutritional Needs
**Correct Answer:** B

### Question 13
**Category:** Business & Sales
**Question:** The DecodeTalent DNA Test [Basic] assesses a combination of 17 traits focusing on which area?
**Options:**
- A. Talent & Learning Ability
- B. Personality & Overall Wellness
- C. EQ & Personality
- D. None of the above
**Correct Answer:** D

### Question 14
**Category:** Business & Sales
**Question:** According to the FAQs, how does the DNA test help mitigate future health risks and justify its cost as a long-term investment?
**Options:**
- A. The test fee is fully covered by health insurance.
- B. The test is repeated annually to monitor changing genes.
- C. It is a once-in-a-lifetime test that helps customers avoid unnecessary spending on ineffective supplements, diets, or programs.
- D. The results automatically generate investment advice for the parents.
**Correct Answer:** C

### Question 15
**Category:** Business & Sales
**Question:** How will a customer know that their child's DNA test report is ready after the 3-4 week processing period?
**Options:**
- A. The report will be automatically mailed to their physical address.
- B. The report will be posted publicly on the AGT website with the child's name.
- C. They will receive a notification via email and a WhatsApp message when the report is ready for viewing on their account.
- D. The affiliate must personally call the customer once the results are published.
**Correct Answer:** C

### Question 16
**Category:** Product Knowledge
**Question:** What's included in the Affiliate Starter Pack?
**Options:**
- A. 5x DNA Test Kit only
- B. 3x A4 Flyers only
- C. 1x Bunting
- D. All the above
**Correct Answer:** D

### Question 17
**Category:** Operations & Procedures
**Question:** What should be avoided within 1 hour before collecting the saliva sample?
**Options:**
- A. Eating or drinking (except plain water)
- B. Smoking
- C. Brush Teeth
- D. Applying lipstick
- E. All of the above
**Correct Answer:** E

### Question 18
**Category:** Product Knowledge
**Question:** Which of the following bundles are products of AGT?
I. Child Bundle
II. Wellness Bundle
III. Adult Bundle
IV. Baby Bundle
**Options:**
- A. I and II
- B. I, II, and III
- C. I, III, and IV
- D. All of the above
**Correct Answer:** B

---

## TIER SYSTEM THRESHOLDS

| Tier | Score Range | Percentage | Badge Display |
|------|-------------|------------|---------------|
| Excellent | 16-18 correct | 89-100% | 🏆 Dark green (#2D5F3F) |
| Good | 14-15 correct | 78-83% | ⭐ Medium green (#4A9B6B) |
| Pass | 12-13 correct | 67-72% | ✔️ Light green (#7BC79D) |
| Need Improvement | 0-11 correct | 0-61% | ⚠️ Yellow (#ffc107) |

---

## FRONTEND PAGES SPECIFICATIONS

### 1. Landing Page (`app/page.tsx`)

**Layout:**
```
┌──────────────────────────────────────────┐
│  [AGT Logo]                    [About]   │
├──────────────────────────────────────────┤
│                                          │
│         [nurture_nature.png]             │
│                                          │
│      AGT Affiliate Training Quiz         │
│                                          │
│   Test your knowledge about AGT          │
│   products and services                  │
│                                          │
│       [Start Quiz Button]                │
│                                          │
└──────────────────────────────────────────┘
```

**Features:**
- Hero section with nurture_nature.png image
- Centered heading: "AGT Affiliate Training Quiz"
- Subheading explaining the quiz
- Primary CTA button: "Start Quiz" → Navigate to /quiz
- Mobile-first responsive layout

---

### 2. Quiz Page (`app/quiz/page.tsx`)

**Step 1: Registration Form**

```
┌──────────────────────────────────────────┐
│  [AGT Logo]                              │
├──────────────────────────────────────────┤
│                                          │
│     Before You Begin                     │
│     Please provide your details          │
│                                          │
│  ┌────────────────────────────────────┐  │
│  │ Full Name *                        │  │
│  │ [___________________________]      │  │
│  └────────────────────────────────────┘  │
│                                          │
│  ┌────────────────────────────────────┐  │
│  │ Email Address *                    │  │
│  │ [___________________________]      │  │
│  └────────────────────────────────────┘  │
│                                          │
│  ┌────────────────────────────────────┐  │
│  │ Phone Number *                     │  │
│  │ [___________________________]      │  │
│  └────────────────────────────────────┘  │
│                                          │
│  ┌────────────────────────────────────┐  │
│  │ Company *                          │  │
│  │ [___________________________]      │  │
│  └────────────────────────────────────┘  │
│                                          │
│  ┌────────────────────────────────────┐  │
│  │ Position *                         │  │
│  │ [___________________________]      │  │
│  └────────────────────────────────────┘  │
│                                          │
│         [Begin Quiz →]                   │
│                                          │
└──────────────────────────────────────────┘
```

**Validation:**
- All 5 fields are REQUIRED
- Email format validation
- Phone number format (any format accepted, no specific validation)
- Show error messages below fields if validation fails
- Disable "Begin Quiz" button until all fields are valid

---

**Step 2: Quiz Interface (Multi-Step)**

```
┌──────────────────────────────────────────┐
│  [AGT Logo]                              │
├──────────────────────────────────────────┤
│                                          │
│  Question 3 of 18                        │
│  ━━━━━━━━━━░░░░░░░░░░░░░░░              │
│                                          │
│  The Decode Talent DNA Test              │
│  [Comprehensive] unlocks children's      │
│  potential by analyzing a total of       │
│  how many personal traits?               │
│                                          │
│  ○ A. 26 nutritional traits              │
│  ○ B. 42 health risk traits              │
│  ○ C. 50 personal traits                 │
│  ○ D. 15 career development traits       │
│                                          │
│                                          │
│  [← Previous]          [Next Question →] │
│                                          │
└──────────────────────────────────────────┘
```

**Quiz Rules:**
- Display ONE question at a time
- Show progress bar: `[3/18] ━━━━━━░░░░░░`
- Radio buttons for options (A, B, C, D, or E depending on question)
- "Previous" button: Go back to previous question (enabled except on Q1)
- "Next" button: Go to next question (disabled until an answer is selected)
- On Question 18: "Next" button changes to "Submit Quiz"
- Users CAN change answers by going back
- No time limit
- Must complete in ONE session (no save and resume)
- Maximum 3 attempts allowed per user (track by email)

**Progress Bar Styling:**
- Filled portion: #2AAFF5 (primary blue)
- Unfilled portion: #dee2e6 (light gray)
- Smooth animation on progress changes

---

### 3. Results Page (`app/results/[submissionId]/page.tsx`)

**Layout:**

```
┌──────────────────────────────────────────────────┐
│  [AGT Logo]                         [Retake Quiz]│
├──────────────────────────────────────────────────┤
│                                                  │
│  ┌────────────────────────────────────────────┐ │
│  │        Your Assessment Results             │ │
│  │                                            │ │
│  │           15 / 18                          │ │
│  │            83%                             │ │
│  │                                            │ │
│  │        ⭐ GOOD                             │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│  ┌────────────────────────────────────────────┐ │
│  │  📊 Comparison                             │ │
│  │  You scored 83%                            │ │
│  │  Average score: 72%                        │ │
│  │  You're above average! 🎉                  │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│  ┌────────────────────────────────────────────┐ │
│  │  🏆 Ranking                                │ │
│  │  You're in the top 25% of all test-takers │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│  ┌────────────────────────────────────────────┐ │
│  │  Category Breakdown                        │ │
│  │                                            │ │
│  │     [RADAR CHART showing 4 categories]     │ │
│  │                                            │ │
│  │  Product Knowledge: 6/7 (86%)              │ │
│  │  Operations & Procedures: 2/3 (67%)        │ │
│  │  Compliance & Privacy: 2/2 (100%)          │ │
│  │  Business & Sales: 5/6 (83%)               │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│  ┌────────────────────────────────────────────┐ │
│  │  💪 Strengths                              │ │
│  │  • Compliance & Privacy (100%)             │ │
│  │  • Product Knowledge (86%)                 │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│  ┌────────────────────────────────────────────┐ │
│  │  📚 Areas for Improvement                  │ │
│  │  • Operations & Procedures (67%)           │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│  ┌────────────────────────────────────────────┐ │
│  │  💡 Personalized Recommendations           │ │
│  │  • Review DNA sampling procedures          │ │
│  │  • Study the ACTN3 gene information        │ │
│  │  • Practice questions on operations        │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│  ┌────────────────────────────────────────────┐ │
│  │  📈 Your Progress (if multiple attempts)   │ │
│  │                                            │ │
│  │     [LINE CHART showing improvement]       │ │
│  │                                            │ │
│  │  Attempt 1: 67%                            │ │
│  │  Attempt 2: 78%                            │ │
│  │  Attempt 3: 83% (Current) ⬆️              │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│  ┌────────────────────────────────────────────┐ │
│  │  Detailed Question Review                  │ │
│  │                                            │ │
│  │  Q1. What is the core business...          │ │
│  │  Category: Product Knowledge               │ │
│  │  Your Answer: B ✅ Correct                 │ │
│  │  ─────────────────────────────────────     │ │
│  │  Q2. What's not included...                │ │
│  │  Category: Product Knowledge               │ │
│  │  Your Answer: A ❌ Incorrect               │ │
│  │  Correct Answer: B                         │ │
│  │  ─────────────────────────────────────     │ │
│  │  [Show all 18 questions]                   │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│         [Retake Quiz]  [Download Report]        │
│                                                  │
└──────────────────────────────────────────────────┘
```

**Features to Implement:**

1. **Score Card**
   - Large display: "15 / 18"
   - Percentage: "83%"
   - Tier badge with appropriate color
   - Icon/emoji based on tier

2. **Comparison with Average**
   - Calculate average score from ALL submissions
   - Show user's score vs average
   - Congratulatory message if above average

3. **Ranking/Leaderboard**
   - Calculate percentile ranking
   - Example: "Top 25% of all test-takers"
   - No names shown (privacy)

4. **Radar Chart (4 Categories)**
   - Use Recharts library
   - Show percentage for each category
   - Color-coded by performance
   - Responsive and animated

5. **Strengths & Weaknesses**
   - Automatically identify top 2 categories (strengths)
   - Automatically identify bottom 2 categories (weaknesses)
   - Display with checkmark/warning icons

6. **Personalized Recommendations**
   - Generate based on wrong answers
   - Example: If user missed Q6 about ACTN3 gene, recommend: "Study the ACTN3 gene information"
   - Show 3-5 specific recommendations

7. **Historical Performance Chart** (if multiple attempts)
   - Only show if user has >1 attempt
   - Line chart showing score progression
   - Use Recharts library
   - Highlight improvement with positive messages

8. **Question-by-Question Review**
   - List all 18 questions
   - Show user's answer
   - Show correct answer
   - Mark correct (✅) or incorrect (❌)
   - Show category for each question
   - Expandable/collapsible for mobile

9. **Retake Quiz Button**
   - Check attempt count
   - If < 3 attempts: Allow retake
   - If = 3 attempts: Disable with message "Maximum attempts reached"

---

### 4. Admin Login Page (`app/admin/page.tsx`)

```
┌──────────────────────────────────────────┐
│                                          │
│         [AGT_LOGO.png]                   │
│                                          │
│       Admin Login Portal                 │
│                                          │
│  ┌────────────────────────────────────┐  │
│  │ Username                           │  │
│  │ [___________________________]      │  │
│  └────────────────────────────────────┘  │
│                                          │
│  ┌────────────────────────────────────┐  │
│  │ Password                           │  │
│  │ [___________________________]      │  │
│  └────────────────────────────────────┘  │
│                                          │
│  [Error: Invalid credentials]            │
│  (only show if login fails)              │
│                                          │
│         [    Login    ]                  │
│                                          │
└──────────────────────────────────────────┘
```

**Features:**
- Centered card layout (max-width 400px)
- AGT logo at top
- Username field
- Password field (type="password")
- Error message (red, only shown on failed login)
- Login button (full width, primary blue)
- On successful login: Set HTTP-only cookie, redirect to /admin/dashboard

**Credentials:**
- Username: `AGT_BD` (from env variable)
- Password: `AGT248` (from env variable)

---

### 5. Admin Dashboard (`app/admin/dashboard/page.tsx`)

```
┌────────────────────────────────────────────────────────────────────┐
│  AGT Admin Dashboard                                   [Logout]    │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐         │
│  │   📝     │  │   📊     │  │   ✅     │  │   ❌     │         │
│  │   120    │  │  78.5%   │  │  100%    │  │   Q13    │         │
│  │  Total   │  │ Average  │  │ Complete │  │  Most    │         │
│  │Submission│  │  Score   │  │   Rate   │  │ Missed   │         │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘         │
│                                                                    │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  Filters:                                                          │
│  [Start Date] [End Date] [Company ▼] [Tier ▼] [Search name/email]│
│  [Apply Filters] [Reset]                           [Export CSV]   │
│                                                                    │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  Submissions Table                                                 │
│  ┌──┬───────────┬────────┬────────┬────────┬────────┬──────┬────┐│
│  │ #│Timestamp  │  Name  │ Email  │ Phone  │Company │Score │... ││
│  ├──┼───────────┼────────┼────────┼────────┼────────┼──────┼────┤│
│  │ 1│01/01/25   │John Doe│john@...│+60123..│ABC Corp│15/18 │    ││
│  │  │10:30:00   │        │        │        │        │83%   │    ││
│  │  │           │        │        │        │        │Good  │    ││
│  ├──┼───────────┼────────┼────────┼────────┼────────┼──────┼────┤│
│  │ 2│01/01/25   │Jane S. │jane@...│+60124..│XYZ Ltd │17/18 │    ││
│  │  │11:45:00   │        │        │        │        │94%   │    ││
│  │  │           │        │        │        │        │Excell│    ││
│  └──┴───────────┴────────┴────────┴────────┴────────┴──────┴────┘│
│                                                                    │
│  Showing 1-10 of 120      [< Prev] [1] [2] [3] [4] [5] [Next >]  │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

**Features:**

1. **Analytics Cards (4 Cards)**
   - Total Submissions: Count all records
   - Average Score: Calculate mean percentage
   - Completion Rate: 100% (all records in DB are complete)
   - Most Missed Question: Find question with highest wrong answer rate

2. **Filters**
   - Date Range: Start date and end date pickers
   - Company: Dropdown with unique companies from submissions
   - Tier: Dropdown (All, Excellent, Good, Pass, Need Improvement)
   - Search: Text input for name or email
   - Apply Filters button: Refresh table with filters
   - Reset button: Clear all filters

3. **Submissions Table (10 Columns)**
   - #: Row number
   - Timestamp: Format as "DD/MM/YYYY HH:MM:SS"
   - Name: Full name
   - Email: Email address
   - Phone: Phone number
   - Company: Company name
   - Score: Format as "15/18 - 83%" with tier badge
   - Tier: Color-coded badge
   - Attempt #: Show 1st, 2nd, or 3rd attempt
   - Actions: (Not needed in Phase 1)

4. **Sortable Columns**
   - Click column header to sort ascending
   - Click again to sort descending
   - Sortable columns: Timestamp, Name, Email, Company, Score, Tier, Attempt
   - Show sort indicator (↑ ↓)

5. **Pagination**
   - 10 items per page
   - Show "Showing X-Y of Z" text
   - Previous/Next buttons
   - Page number buttons (show 5 pages max)
   - Disable Previous on page 1
   - Disable Next on last page

6. **Export to CSV**
   - Button in top-right of filters section
   - Generate CSV with all columns
   - Include filtered data only
   - Filename: `AGT_Submissions_YYYY-MM-DD.csv`
   - Auto-download on click

7. **Logout Button**
   - Top-right corner
   - Clear HTTP-only cookie
   - Redirect to /admin

---

## BACKEND API ROUTES SPECIFICATIONS

### 1. Admin Login API (`app/api/admin/login/route.ts`)

**Endpoint:** `POST /api/admin/login`

**Request Body:**
```json
{
  "username": "AGT_BD",
  "password": "AGT248"
}
```

**Logic:**
1. Validate username and password against environment variables
2. If correct:
   - Set HTTP-only cookie: `agt_admin_auth = "authenticated"`
   - Cookie settings:
     - httpOnly: true
     - secure: true (in production)
     - sameSite: "strict"
     - maxAge: 28800 (8 hours in seconds)
   - Return success response
3. If incorrect:
   - Return 401 error

**Response (Success):**
```json
{
  "success": true
}
```

**Response (Error):**
```json
{
  "error": "Invalid credentials"
}
```

---

### 2. Quiz Submission API (`app/api/quiz/submit/route.ts`)

**Endpoint:** `POST /api/quiz/submit`

**Request Body:**
```json
{
  "userData": {
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+60123456789",
    "company": "ABC Corp",
    "position": "Sales Manager"
  },
  "answers": [
    { "questionId": 1, "selected": "B" },
    { "questionId": 2, "selected": "A" },
    ...
  ]
}
```

**Logic:**
1. Validate all required fields
2. Check attempt count for this email (max 3)
3. Calculate score:
   - Compare each answer with correct answer from questions data
   - Count correct answers
   - Calculate percentage
4. Determine tier based on thresholds
5. Calculate category scores
6. Determine attempt number (1st, 2nd, or 3rd)
7. Save to Vercel Postgres
8. Send email notification to ikhmal@agtgenetics.com
9. Return submission ID

**Response:**
```json
{
  "success": true,
  "submissionId": "uuid-here",
  "score": 15,
  "percentage": 83.33,
  "tier": "Good",
  "attemptNumber": 1
}
```

**Email Template:**
```html
<h2>🎯 New Quiz Submission</h2>
<p><strong>Name:</strong> John Doe</p>
<p><strong>Email:</strong> john@example.com</p>
<p><strong>Company:</strong> ABC Corp</p>
<p><strong>Score:</strong> 15/18 (83%)</p>
<p><strong>Tier:</strong> Good</p>
<p><strong>Timestamp:</strong> 2025-01-03 14:30:00</p>
<p><a href="https://yourapp.vercel.app/admin/dashboard">View in Dashboard</a></p>
```

---

### 3. Get Submissions API (`app/api/submissions/route.ts`)

**Endpoint:** `GET /api/submissions`

**Query Parameters:**
- `startDate`: Filter by start date (optional)
- `endDate`: Filter by end date (optional)
- `company`: Filter by company (optional)
- `tier`: Filter by tier (optional)
- `search`: Search by name or email (optional)
- `page`: Page number (default: 1)
- `limit`: Items per page (default: 10)
- `sortBy`: Column to sort by (optional)
- `sortOrder`: "asc" or "desc" (default: "desc")

**Authentication:**
- Check for `agt_admin_auth` cookie
- Return 401 if not authenticated

**Logic:**
1. Verify admin authentication
2. Build SQL query with filters
3. Apply pagination
4. Apply sorting
5. Return submissions with metadata

**Response:**
```json
{
  "submissions": [...],
  "pagination": {
    "currentPage": 1,
    "totalPages": 12,
    "totalItems": 120,
    "itemsPerPage": 10
  },
  "filters": {
    "startDate": "2025-01-01",
    "endDate": "2025-01-31",
    "company": "ABC Corp",
    "tier": "Good",
    "search": "john"
  }
}
```

---

### 4. Get Single Submission API (`app/api/submissions/[id]/route.ts`)

**Endpoint:** `GET /api/submissions/[id]`

**Logic:**
1. Fetch submission by ID
2. Calculate comparison metrics:
   - Average score of all users
   - User's ranking (percentile)
3. Fetch user's all attempts (by email)
4. Generate recommendations based on wrong answers
5. Return complete data

**Response:**
```json
{
  "submission": {
    "id": "uuid",
    "timestamp": "2025-01-03T14:30:00Z",
    "userData": {...},
    "score": 15,
    "percentage": 83.33,
    "tier": "Good",
    "answers": [...],
    "categoryScores": {...},
    "attemptNumber": 1
  },
  "analytics": {
    "averageScore": 72.5,
    "ranking": "Top 25%",
    "userAttempts": [
      { "attempt": 1, "score": 15, "percentage": 83.33, "date": "..." }
    ],
    "recommendations": [
      "Review DNA sampling procedures",
      "Study the ACTN3 gene information"
    ],
    "strengths": ["Compliance & Privacy", "Product Knowledge"],
    "weaknesses": ["Operations & Procedures"]
  }
}
```

---

### 5. Analytics API (`app/api/analytics/route.ts`)

**Endpoint:** `GET /api/analytics`

**Authentication:**
- Check for `agt_admin_auth` cookie
- Return 401 if not authenticated

**Logic:**
1. Calculate total submissions
2. Calculate average score
3. Calculate most missed question
4. Calculate completion rate (100% for all in DB)

**Response:**
```json
{
  "totalSubmissions": 120,
  "averageScore": 78.5,
  "completionRate": 100,
  "mostMissedQuestion": {
    "questionId": 13,
    "questionText": "The DecodeTalent DNA Test [Basic]...",
    "missRate": 45.8
  }
}
```

---

### 6. Export CSV API (`app/api/export/csv/route.ts`)

**Endpoint:** `GET /api/export/csv`

**Authentication:**
- Check for `agt_admin_auth` cookie
- Return 401 if not authenticated

**Query Parameters:**
- Same filters as GET /api/submissions

**Logic:**
1. Fetch filtered submissions
2. Generate CSV content
3. Set headers for file download
4. Return CSV file

**CSV Headers:**
```
#,Timestamp,Name,Email,Phone,Company,Position,Score,Percentage,Tier,Attempt,Product Knowledge,Operations & Procedures,Compliance & Privacy,Business & Sales
```

**Response:**
- Content-Type: `text/csv`
- Content-Disposition: `attachment; filename="AGT_Submissions_2025-01-03.csv"`

---

## MIDDLEWARE PROTECTION

### File: `middleware.ts` (root level)

```typescript
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  // Protect /admin/dashboard routes
  if (request.nextUrl.pathname.startsWith('/admin/dashboard')) {
    const authCookie = request.cookies.get('agt_admin_auth');
    
    if (!authCookie || authCookie.value !== 'authenticated') {
      return NextResponse.redirect(new URL('/admin', request.url));
    }
  }
  
  return NextResponse.next();
}

export const config = {
  matcher: '/admin/dashboard/:path*'
};
```

**Purpose:**
- Intercept all requests to /admin/dashboard/*
- Check for valid authentication cookie
- Redirect to /admin login if not authenticated
- Allow request to proceed if authenticated

---

## LIB UTILITIES

### 1. Questions Data (`lib/questions.ts`)

```typescript
export interface Question {
  id: number;
  category: string;
  question: string;
  options: string[];
  correctAnswer: string;
}

export const questions: Question[] = [
  {
    id: 1,
    category: "Product Knowledge",
    question: "What is the core business or brand identity of Absolute Genetic Technologies (AGT), as primarily emphasized throughout the materials?",
    options: [
      "A. A general technology firm specializing in bioinformatics analysis and data security compliance.",
      "B. A provider of specialized, science-backed, Asian-tailored DNA tests primarily focused on improving early childhood development (talent, nutrition, health, career) and secondarily offering wellness/career DNA tests for everyone.",
      "C. An internationally accredited laboratory based in Singapore dedicated solely to DNA extraction and genotyping procedures.",
      "D. A consultation service that helps customers save money by avoiding unnecessary spending on ineffective supplements and diets."
    ],
    correctAnswer: "B"
  },
  // ... all 18 questions (copy word-for-word from PDF)
];

export const categoryMapping = {
  "Product Knowledge": [1, 2, 3, 4, 5, 16, 18],
  "Operations & Procedures": [6, 7, 17],
  "Compliance & Privacy": [10, 11],
  "Business & Sales": [8, 9, 12, 13, 14, 15]
};
```

---

### 2. Database Connection (`lib/db.ts`)

```typescript
import { sql } from '@vercel/postgres';

export { sql };

// Helper to initialize database
export async function initializeDatabase() {
  await sql`
    CREATE TABLE IF NOT EXISTS submissions (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) NOT NULL,
      phone VARCHAR(20) NOT NULL,
      company VARCHAR(255) NOT NULL,
      position VARCHAR(255) NOT NULL,
      answers JSONB NOT NULL,
      score INTEGER NOT NULL,
      percentage DECIMAL(5,2) NOT NULL,
      tier VARCHAR(50) NOT NULL,
      category_scores JSONB NOT NULL,
      attempt_number INTEGER NOT NULL
    )
  `;
  
  await sql`CREATE INDEX IF NOT EXISTS idx_email ON submissions(email)`;
  await sql`CREATE INDEX IF NOT EXISTS idx_timestamp ON submissions(timestamp)`;
  await sql`CREATE INDEX IF NOT EXISTS idx_tier ON submissions(tier)`;
}
```

---

### 3. Scoring Logic (`lib/scoring.ts`)

```typescript
import { questions, categoryMapping } from './questions';

export interface Answer {
  questionId: number;
  selected: string;
}

export interface CategoryScore {
  correct: number;
  total: number;
}

export function calculateScore(answers: Answer[]) {
  let correct = 0;
  const detailedAnswers = [];
  
  answers.forEach(answer => {
    const question = questions.find(q => q.id === answer.questionId);
    const isCorrect = answer.selected === question?.correctAnswer;
    
    if (isCorrect) correct++;
    
    detailedAnswers.push({
      questionId: answer.questionId,
      selected: answer.selected,
      correct: isCorrect
    });
  });
  
  const percentage = (correct / questions.length) * 100;
  
  return {
    score: correct,
    totalQuestions: questions.length,
    percentage,
    detailedAnswers
  };
}

export function determineTier(percentage: number): string {
  if (percentage >= 89) return 'Excellent';
  if (percentage >= 78) return 'Good';
  if (percentage >= 67) return 'Pass';
  return 'Need Improvement';
}

export function calculateCategoryScores(answers: Answer[]): Record<string, CategoryScore> {
  const scores: Record<string, CategoryScore> = {};
  
  Object.entries(categoryMapping).forEach(([category, questionIds]) => {
    const categoryAnswers = answers.filter(a => questionIds.includes(a.questionId));
    const correct = categoryAnswers.filter(a => {
      const question = questions.find(q => q.id === a.questionId);
      return a.selected === question?.correctAnswer;
    }).length;
    
    scores[category] = {
      correct,
      total: questionIds.length
    };
  });
  
  return scores;
}

export function generateRecommendations(answers: Answer[]): string[] {
  const recommendations: string[] = [];
  const wrongAnswers = answers.filter(a => {
    const question = questions.find(q => q.id === a.questionId);
    return a.selected !== question?.correctAnswer;
  });
  
  // Generate specific recommendations based on wrong answers
  wrongAnswers.forEach(wrong => {
    const question = questions.find(q => q.id === wrong.questionId);
    if (question) {
      // Add specific recommendations based on question category
      if (question.category === 'Operations & Procedures') {
        recommendations.push('Review DNA sampling procedures and techniques');
      }
      if (question.id === 6) {
        recommendations.push('Study the ACTN3 gene and its role in sports performance');
      }
      // Add more specific recommendations based on question IDs
    }
  });
  
  return [...new Set(recommendations)]; // Remove duplicates
}
```

---

### 4. Email Service (`lib/email.ts`)

```typescript
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export interface SubmissionData {
  name: string;
  email: string;
  company: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  tier: string;
  timestamp: string;
}

export async function sendAdminNotification(data: SubmissionData) {
  try {
    await resend.emails.send({
      from: 'AGT Quiz Notifications <noreply@yourdomain.com>',
      to: process.env.ADMIN_EMAIL!,
      subject: `🎯 New Quiz Submission - ${data.name}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #2AAFF5;">🎯 New Quiz Submission</h2>
          
          <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p><strong>Name:</strong> ${data.name}</p>
            <p><strong>Email:</strong> ${data.email}</p>
            <p><strong>Company:</strong> ${data.company}</p>
            <p><strong>Score:</strong> ${data.score}/${data.totalQuestions} (${data.percentage.toFixed(1)}%)</p>
            <p><strong>Tier:</strong> <span style="color: ${getTierColor(data.tier)};">${data.tier}</span></p>
            <p><strong>Timestamp:</strong> ${data.timestamp}</p>
          </div>
          
          <a href="${process.env.NEXT_PUBLIC_APP_URL}/admin/dashboard" 
             style="display: inline-block; background: #2AAFF5; color: white; padding: 12px 24px; 
                    text-decoration: none; border-radius: 8px; margin-top: 20px;">
            View in Dashboard
          </a>
        </div>
      `
    });
  } catch (error) {
    console.error('Failed to send email notification:', error);
    // Don't throw error - email failure shouldn't break submission
  }
}

function getTierColor(tier: string): string {
  const colors = {
    'Excellent': '#2D5F3F',
    'Good': '#4A9B6B',
    'Pass': '#7BC79D',
    'Need Improvement': '#ffc107'
  };
  return colors[tier] || '#6c757d';
}
```

---

### 5. General Utilities (`lib/utils.ts`)

```typescript
export function formatTimestamp(date: Date | string): string {
  const d = new Date(date);
  return d.toLocaleString('en-MY', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
}

export function validateEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

export function exportToCSV(data: any[], filename: string) {
  // CSV generation logic
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(row => 
      headers.map(header => `"${row[header]}"`).join(',')
    )
  ].join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function calculatePercentile(score: number, allScores: number[]): number {
  const sorted = allScores.sort((a, b) => a - b);
  const index = sorted.findIndex(s => s >= score);
  return ((index + 1) / sorted.length) * 100;
}
```

---

## COMPONENT SPECIFICATIONS

### 1. RegistrationForm Component

**File:** `components/quiz/RegistrationForm.tsx`

**Props:**
```typescript
interface RegistrationFormProps {
  onSubmit: (data: UserData) => void;
}

interface UserData {
  name: string;
  email: string;
  phone: string;
  company: string;
  position: string;
}
```

**Features:**
- 5 input fields (all required)
- Client-side validation
- Error messages below each field
- Disabled submit button until valid
- Loading state during submission

---

### 2. QuestionCard Component

**File:** `components/quiz/QuestionCard.tsx`

**Props:**
```typescript
interface QuestionCardProps {
  question: Question;
  selectedAnswer: string | null;
  onSelectAnswer: (answer: string) => void;
}
```

**Features:**
- Display question text
- Radio buttons for options
- Highlight selected answer
- Mobile-friendly tap targets

---

### 3. ProgressBar Component

**File:** `components/quiz/ProgressBar.tsx`

**Props:**
```typescript
interface ProgressBarProps {
  current: number;
  total: number;
}
```

**Features:**
- Visual progress bar
- Text indicator: "3 / 18"
- Smooth animation on progress change
- Responsive width

---

### 4. RadarChart Component

**File:** `components/results/RadarChart.tsx`

**Props:**
```typescript
interface RadarChartProps {
  data: CategoryScore[];
}
```

**Features:**
- Use Recharts library
- Show 4 categories
- Color-coded by performance
- Responsive sizing
- Animated on load

**Example:**
```typescript
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from 'recharts';

const data = [
  { category: 'Product Knowledge', score: 86 },
  { category: 'Operations', score: 67 },
  { category: 'Compliance', score: 100 },
  { category: 'Business', score: 83 }
];

<ResponsiveContainer width="100%" height={300}>
  <RadarChart data={data}>
    <PolarGrid />
    <PolarAngleAxis dataKey="category" />
    <PolarRadiusAxis domain={[0, 100]} />
    <Radar dataKey="score" stroke="#2AAFF5" fill="#2AAFF5" fillOpacity={0.6} />
  </RadarChart>
</ResponsiveContainer>
```

---

### 5. SubmissionsTable Component

**File:** `components/admin/SubmissionsTable.tsx`

**Props:**
```typescript
interface SubmissionsTableProps {
  submissions: Submission[];
  sortConfig: { key: string; direction: 'asc' | 'desc' } | null;
  onSort: (key: string) => void;
}
```

**Features:**
- Responsive table (horizontal scroll on mobile)
- Sortable column headers
- Tier badges with colors
- Formatted timestamps
- Hover effects on rows

---

## ENVIRONMENT VARIABLES

### Development (`.env.local`)

```bash
# Admin Credentials
ADMIN_USERNAME=AGT_BD
ADMIN_PASSWORD=AGT248

# Vercel Postgres (auto-generated when you create database)
POSTGRES_URL="postgresql://..."
POSTGRES_PRISMA_URL="postgresql://..."
POSTGRES_URL_NON_POOLING="postgresql://..."
POSTGRES_USER="..."
POSTGRES_HOST="..."
POSTGRES_PASSWORD="..."
POSTGRES_DATABASE="..."

# Email Service (Resend)
RESEND_API_KEY=re_...
ADMIN_EMAIL=ikhmal@agtgenetics.com

# App URL
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### Production (Vercel Dashboard)

Set same variables in Vercel project settings under "Environment Variables"

---

## DEPLOYMENT CHECKLIST

### Pre-Deployment

1. ✅ Install dependencies:
   ```bash
   npm install next react react-dom typescript
   npm install @vercel/postgres
   npm install resend
   npm install recharts
   npm install -D tailwindcss postcss autoprefixer
   npm install -D @types/node @types/react @types/react-dom
   ```

2. ✅ Configure `tailwind.config.js`:
   ```javascript
   module.exports = {
     content: [
       './app/**/*.{js,ts,jsx,tsx,mdx}',
       './components/**/*.{js,ts,jsx,tsx,mdx}',
     ],
     theme: {
       extend: {
         colors: {
           'primary-blue': '#2AAFF5',
           'secondary-blue': '#05087F',
         },
         fontFamily: {
           montserrat: ['Montserrat', 'sans-serif'],
           inter: ['Inter', 'sans-serif'],
         },
       },
     },
   }
   ```

3. ✅ Add fonts in `app/layout.tsx`:
   ```typescript
   import { Montserrat, Inter } from 'next/font/google';
   
   const montserrat = Montserrat({ 
     subsets: ['latin'],
     weight: ['400', '600'],
     variable: '--font-montserrat'
   });
   
   const inter = Inter({ 
     subsets: ['latin'],
     weight: ['400', '500'],
     variable: '--font-inter'
   });
   ```

4. ✅ Upload images to `/public/images/`:
   - AGT_LOGO.png
   - nurture_nature.png
   - learning_ability.png
   - Untitled-1-03.png

### Vercel Deployment Steps

1. **Push to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin <your-github-repo>
   git push -u origin main
   ```

2. **Connect to Vercel:**
   - Go to vercel.com
   - Click "Import Project"
   - Select your GitHub repository
   - Vercel auto-detects Next.js

3. **Create Vercel Postgres Database:**
   - In Vercel project dashboard
   - Go to "Storage" tab
   - Click "Create Database"
   - Select "Postgres"
   - Copy connection strings to environment variables

4. **Set Environment Variables:**
   - In Vercel dashboard: Settings → Environment Variables
   - Add all variables from `.env.local`
   - Deploy

5. **Initialize Database:**
   - After first deployment, run database initialization
   - Can add an API route: `/api/admin/init-db` (protected)
   - Call once to create tables

6. **Sign up for Resend:**
   - Go to resend.com
   - Create account
   - Get API key
   - Add to Vercel environment variables
   - Verify sender domain (or use default resend domain for testing)

### Post-Deployment

1. ✅ Test admin login
2. ✅ Test quiz submission flow
3. ✅ Verify email notifications
4. ✅ Check results page with all features
5. ✅ Test admin dashboard filters and export
6. ✅ Test on mobile devices
7. ✅ Verify database persistence

---

## TESTING REQUIREMENTS

### Manual Testing Checklist

**Quiz Flow:**
- [ ] Landing page loads with correct images
- [ ] Registration form validates all fields
- [ ] Quiz displays one question at a time
- [ ] Progress bar updates correctly
- [ ] Previous/Next navigation works
- [ ] Can change answers by going back
- [ ] Submit on question 18 saves to database
- [ ] Redirect to results page with correct ID

**Results Page:**
- [ ] Score displays correctly
- [ ] Tier badge shows correct color
- [ ] Radar chart renders with 4 categories
- [ ] Comparison with average calculates correctly
- [ ] Ranking displays as percentile
- [ ] Strengths/weaknesses auto-generated correctly
- [ ] Recommendations relevant to wrong answers
- [ ] Historical chart shows if multiple attempts
- [ ] Question review shows all 18 with correct/wrong
- [ ] Retake button works (max 3 attempts)

**Admin Dashboard:**
- [ ] Login rejects wrong credentials
- [ ] Login accepts correct credentials (AGT_BD / AGT248)
- [ ] Dashboard protected (redirects if not logged in)
- [ ] Analytics cards calculate correctly
- [ ] Table displays all submissions
- [ ] Sorting works on all sortable columns
- [ ] Filters work (date, company, tier, search)
- [ ] Pagination works correctly
- [ ] Export CSV downloads with correct data
- [ ] Logout clears session and redirects

**Email Notifications:**
- [ ] Admin receives email on every submission
- [ ] Email contains correct data
- [ ] Email link to dashboard works

**Mobile Responsiveness:**
- [ ] All pages work on mobile (< 768px)
- [ ] Touch targets are large enough
- [ ] Text is readable without zooming
- [ ] Tables scroll horizontally if needed
- [ ] Forms are easy to fill on mobile

---

## COMMON ISSUES & SOLUTIONS

### Issue 1: Vercel Postgres Connection Fails

**Solution:**
```typescript
// Use @vercel/postgres package, not pg or other drivers
import { sql } from '@vercel/postgres';

// Ensure environment variables are set in Vercel dashboard
// Test with a simple query:
const result = await sql`SELECT NOW()`;
```

### Issue 2: Middleware Not Protecting Routes

**Solution:**
```typescript
// Ensure middleware.ts is in root directory (not in app/)
// Check matcher config:
export const config = {
  matcher: '/admin/dashboard/:path*'  // Correct format
};
```

### Issue 3: Email Not Sending

**Solution:**
```typescript
// Check Resend API key is correct
// Verify sender email domain
// For testing, use resend's default domain: onboarding@resend.dev
// Check Resend dashboard for delivery logs
```

### Issue 4: Recharts Not Rendering

**Solution:**
```typescript
// Ensure you're using ResponsiveContainer
// Set explicit width and height
// Import all necessary components from 'recharts'
// Use 'use client' directive in component
```

### Issue 5: Cookie Not Persisting

**Solution:**
```typescript
// Ensure httpOnly: true in production
// Check secure: process.env.NODE_ENV === 'production'
// Verify maxAge is in seconds, not milliseconds
// Use sameSite: 'strict'
```

---

## STRETCH GOALS (Future Enhancements)

### Phase 2 Features (Not in MVP)

1. **Admin Dashboard Enhancements:**
   - View detailed submission modal
   - Delete submissions with confirmation
   - Highlight best score per user
   - Advanced analytics charts (trend over time)

2. **User Features:**
   - Email verification before quiz
   - Password-protected results page
   - Share results on social media
   - Print results as PDF

3. **Affiliate System:**
   - Promo code tracking
   - Affiliate dashboard
   - Commission calculation
   - Affiliate performance reports

4. **Advanced Analytics:**
   - Category-wise performance trends
   - Question difficulty analysis
   - User behavior tracking (time per question)
   - A/B testing different question orders

---

## SUCCESS CRITERIA

### MVP is considered complete when:

1. ✅ Users can take the 18-question quiz with proper validation
2. ✅ Results page shows all required features (score, chart, comparison, recommendations, leaderboard, review)
3. ✅ Admin can log in securely
4. ✅ Admin dashboard displays all submissions with filters and export
5. ✅ Email notification sent to ikhmal@agtgenetics.com on each submission
6. ✅ Database persists all data correctly
7. ✅ Application is mobile-responsive
8. ✅ Deployed successfully on Vercel
9. ✅ All 18 questions are word-for-word from PDF
10. ✅ No console errors or warnings

---

## FINAL NOTES

- **Mobile-First:** Design for mobile screens first, then scale up
- **Type Safety:** Use TypeScript strictly (no `any` types)
- **Error Handling:** All API routes should have try-catch blocks
- **Loading States:** Show spinners during async operations
- **Accessibility:** Use semantic HTML, proper ARIA labels
- **SEO:** Add proper meta tags in layout.tsx
- **Performance:** Optimize images (use Next.js Image component)
- **Security:** Never expose sensitive data in client-side code

---

**THIS PROMPT IS NOW COMPLETE AND PRODUCTION-READY! 🚀**

Copy this entire specification to your development environment and start building. All requirements, features, and technical details are included. Good luck with your AGT Quiz Application!

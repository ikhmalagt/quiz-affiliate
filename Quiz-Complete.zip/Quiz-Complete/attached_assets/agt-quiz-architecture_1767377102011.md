# AGT AFFILIATE TRAINING QUIZ - COMPLETE ARCHITECTURE

## 🏗️ APPLICATION STRUCTURE

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         AGT QUIZ APPLICATION                             │
│                    (Next.js 14+ App Router + TypeScript)                 │
└─────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                           FRONTEND PAGES                                  │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  📄 app/page.tsx                                                         │
│     ├─ Landing Page (Hero with nurture_nature.png)                      │
│     ├─ Quiz Introduction                                                │
│     └─ "Start Quiz" CTA Button                                          │
│                                                                          │
│  📝 app/quiz/page.tsx                                                    │
│     ├─ User Registration Form (Name, Email, Phone, Company, Position)   │
│     ├─ Multi-step Quiz Interface (1 question per page)                  │
│     ├─ Progress Bar: [3/18] ━━━━━━━░░░░░░░                             │
│     ├─ Navigation: [← Previous] [Next →]                                │
│     └─ Submit when complete                                             │
│                                                                          │
│  📊 app/results/[submissionId]/page.tsx                                 │
│     ├─ Overall Score: 15/18 (83%)                                       │
│     ├─ Tier Badge: 🏆 Excellent / ⭐ Good / ✔️ Pass / ⚠️ Need Improve │
│     ├─ Comparison: "You scored 83%, average is 72%"                     │
│     ├─ Radar Chart: 4 categories breakdown                              │
│     ├─ Question-by-Question Review (all 18 with correct answers)        │
│     ├─ Strengths/Weaknesses Summary                                     │
│     ├─ Personalized Recommendations                                     │
│     ├─ Historical Performance Chart (if retakes exist)                  │
│     ├─ Leaderboard Ranking: "Top 15% of all test-takers"               │
│     └─ [Retake Quiz] button                                             │
│                                                                          │
│  🔐 app/admin/page.tsx                                                   │
│     ├─ Admin Login Form                                                 │
│     ├─ Username: AGT_BD                                                 │
│     ├─ Password: AGT248                                                 │
│     └─ Login via API route                                              │
│                                                                          │
│  🎛️ app/admin/dashboard/page.tsx                                        │
│     ├─ Protected Route (middleware checks cookie)                       │
│     ├─ Analytics Cards (4 cards):                                       │
│     │   • Total Submissions                                             │
│     │   • Average Score                                                 │
│     │   • Completion Rate                                               │
│     │   • Most Missed Question                                          │
│     ├─ Filters:                                                         │
│     │   • Date Range (start/end)                                        │
│     │   • Company Dropdown                                              │
│     │   • Tier Dropdown                                                 │
│     │   • Search (name/email)                                           │
│     ├─ Submissions Table (10 columns):                                  │
│     │   #, Timestamp, Name, Email, Phone, Company, Score, Tier,         │
│     │   Attempt #, Actions                                              │
│     ├─ Sortable Columns                                                 │
│     ├─ Pagination (10 per page)                                         │
│     ├─ Export to CSV button                                             │
│     └─ [Logout] button                                                  │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                           BACKEND API ROUTES                              │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  🔌 app/api/admin/login/route.ts                                        │
│     POST /api/admin/login                                               │
│     ├─ Validates username/password against env variables                │
│     ├─ Sets HTTP-only cookie: agt_admin_auth                           │
│     └─ Returns success/failure                                          │
│                                                                          │
│  🔌 app/api/quiz/submit/route.ts                                        │
│     POST /api/quiz/submit                                               │
│     ├─ Receives: userData + answers[]                                   │
│     ├─ Validates all fields required                                    │
│     ├─ Calculates score, percentage, tier, category breakdown           │
│     ├─ Saves to Vercel Postgres                                         │
│     ├─ Sends email notification to ikhmal@agtgenetics.com              │
│     └─ Returns submissionId for results page                            │
│                                                                          │
│  🔌 app/api/submissions/route.ts                                        │
│     GET /api/submissions                                                │
│     ├─ Protected: Checks admin cookie                                   │
│     ├─ Query params: filters (date, company, tier, search)              │
│     ├─ Returns paginated submissions with analytics                     │
│     └─ Used by admin dashboard                                          │
│                                                                          │
│  🔌 app/api/submissions/[id]/route.ts                                   │
│     GET /api/submissions/[id]                                           │
│     ├─ Returns single submission with full details                      │
│     ├─ Calculates comparison metrics (avg score, ranking)               │
│     ├─ Fetches user's historical attempts                               │
│     └─ Used by results page                                             │
│                                                                          │
│  🔌 app/api/analytics/route.ts                                          │
│     GET /api/analytics                                                  │
│     ├─ Protected: Admin only                                            │
│     ├─ Calculates: total, avg score, most missed question               │
│     └─ Used by admin dashboard cards                                    │
│                                                                          │
│  🔌 app/api/export/csv/route.ts                                         │
│     GET /api/export/csv                                                 │
│     ├─ Protected: Admin only                                            │
│     ├─ Generates CSV with all submissions                               │
│     └─ Returns file download                                            │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          DATABASE SCHEMA                                  │
│                        (Vercel Postgres)                                  │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  TABLE: submissions                                                      │
│  ┌────────────────────┬──────────────┬─────────────────────────────┐   │
│  │ Column             │ Type         │ Description                 │   │
│  ├────────────────────┼──────────────┼─────────────────────────────┤   │
│  │ id                 │ UUID         │ Primary key                 │   │
│  │ timestamp          │ TIMESTAMP    │ Submission date/time        │   │
│  │ name               │ VARCHAR(255) │ User full name              │   │
│  │ email              │ VARCHAR(255) │ User email                  │   │
│  │ phone              │ VARCHAR(20)  │ Phone number                │   │
│  │ company            │ VARCHAR(255) │ Company name                │   │
│  │ position           │ VARCHAR(255) │ Job position                │   │
│  │ answers            │ JSONB        │ Array of 18 answers         │   │
│  │ score              │ INTEGER      │ Correct answers (0-18)      │   │
│  │ percentage         │ DECIMAL(5,2) │ Score percentage            │   │
│  │ tier               │ VARCHAR(50)  │ Performance tier            │   │
│  │ category_scores    │ JSONB        │ Breakdown by 4 categories   │   │
│  │ attempt_number     │ INTEGER      │ User's attempt # (1,2,3)    │   │
│  └────────────────────┴──────────────┴─────────────────────────────┘   │
│                                                                          │
│  INDEXES:                                                                │
│  • idx_email (for finding user's previous attempts)                     │
│  • idx_timestamp (for date filtering)                                   │
│  • idx_tier (for tier filtering)                                        │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          COMPONENTS STRUCTURE                             │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  📦 components/                                                          │
│     ├─ quiz/                                                            │
│     │   ├─ RegistrationForm.tsx    (5 required fields)                 │
│     │   ├─ QuestionCard.tsx         (Single question display)          │
│     │   ├─ ProgressBar.tsx          (3/18 visual progress)             │
│     │   └─ QuizNavigation.tsx       (Previous/Next buttons)            │
│     │                                                                   │
│     ├─ results/                                                         │
│     │   ├─ ScoreCard.tsx            (Overall score display)            │
│     │   ├─ TierBadge.tsx            (Excellent/Good/Pass badge)        │
│     │   ├─ RadarChart.tsx           (4 categories chart - Recharts)    │
│     │   ├─ ComparisonCard.tsx       (vs average score)                 │
│     │   ├─ StrengthsWeaknesses.tsx  (Analysis summary)                 │
│     │   ├─ Recommendations.tsx      (Personalized tips)                │
│     │   ├─ HistoricalChart.tsx      (Improvement over attempts)        │
│     │   ├─ Leaderboard.tsx          (Ranking display)                  │
│     │   └─ AnswerReview.tsx         (All 18 Q&A with explanations)    │
│     │                                                                   │
│     ├─ admin/                                                           │
│     │   ├─ LoginForm.tsx            (Username/password form)           │
│     │   ├─ AnalyticsCards.tsx       (4 metric cards)                   │
│     │   ├─ FilterBar.tsx            (Date/company/tier/search)         │
│     │   ├─ SubmissionsTable.tsx     (Main data table)                  │
│     │   ├─ Pagination.tsx           (Page navigation)                  │
│     │   └─ ExportButton.tsx         (CSV export trigger)               │
│     │                                                                   │
│     └─ shared/                                                          │
│         ├─ Header.tsx               (AGT logo + navigation)             │
│         ├─ Button.tsx               (Reusable button component)         │
│         └─ LoadingSpinner.tsx       (Loading states)                    │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          LIB / UTILITIES                                  │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  📚 lib/                                                                 │
│     ├─ questions.ts                                                     │
│     │   └─ 18 questions (word-for-word from PDF)                       │
│     │       • Question text                                             │
│     │       • Options A, B, C, D, E                                     │
│     │       • Correct answer                                            │
│     │       • Category assignment                                       │
│     │                                                                   │
│     ├─ db.ts                                                            │
│     │   └─ Vercel Postgres connection setup                            │
│     │       • Connection pooling                                        │
│     │       • Query helpers                                             │
│     │                                                                   │
│     ├─ scoring.ts                                                       │
│     │   └─ Score calculation logic                                     │
│     │       • calculateScore(answers)                                   │
│     │       • determineTier(percentage)                                 │
│     │       • calculateCategoryScores(answers)                          │
│     │       • calculateAverageScore(allSubmissions)                     │
│     │       • calculateRanking(score, allScores)                        │
│     │                                                                   │
│     ├─ email.ts                                                         │
│     │   └─ Email notification via Resend                               │
│     │       • sendAdminNotification(submissionData)                     │
│     │       • Email template HTML                                       │
│     │                                                                   │
│     ├─ auth.ts                                                          │
│     │   └─ Authentication helpers                                       │
│     │       • verifyAdminCookie(request)                                │
│     │       • hashPassword (if needed later)                            │
│     │                                                                   │
│     └─ utils.ts                                                         │
│         └─ General utilities                                            │
│             • formatTimestamp(date)                                     │
│             • exportToCSV(data)                                         │
│             • validateEmail(email)                                      │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          MIDDLEWARE & PROTECTION                          │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  🛡️ middleware.ts (Root level)                                          │
│     └─ Protects /admin/dashboard/* routes                               │
│         • Checks for agt_admin_auth cookie                              │
│         • Redirects to /admin if not authenticated                      │
│         • Runs before every request to protected routes                 │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          ENVIRONMENT VARIABLES                            │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  📝 .env.local (Development)                                             │
│     ADMIN_USERNAME=AGT_BD                                                │
│     ADMIN_PASSWORD=AGT248                                                │
│     POSTGRES_URL=postgresql://...                                        │
│     POSTGRES_PRISMA_URL=...                                              │
│     POSTGRES_URL_NON_POOLING=...                                         │
│     RESEND_API_KEY=re_...                                                │
│     ADMIN_EMAIL=ikhmal@agtgenetics.com                                   │
│     NEXT_PUBLIC_APP_URL=http://localhost:3000                            │
│                                                                          │
│  🔒 Vercel Environment Variables (Production)                            │
│     Same as above, set in Vercel Dashboard                               │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          STYLING & DESIGN                                 │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  🎨 Design System                                                        │
│     ├─ Framework: Tailwind CSS                                          │
│     ├─ Fonts:                                                           │
│     │   • Montserrat (Headings, Buttons - 600 weight)                  │
│     │   • Inter (Body text - 400/500 weight)                           │
│     ├─ Colors:                                                          │
│     │   • Primary Blue: #2AAFF5                                         │
│     │   • Secondary Blue: #05087F                                       │
│     │   • Excellent: #2D5F3F (dark green)                              │
│     │   • Good: #4A9B6B (medium green)                                 │
│     │   • Pass: #7BC79D (light green)                                  │
│     │   • Need Improvement: #ffc107 (yellow)                           │
│     │   • Text: #212529 (dark gray)                                    │
│     │   • Border: #dee2e6 (light gray)                                 │
│     │   • Background: #f8f9fa (off-white)                              │
│     ├─ Components:                                                      │
│     │   • Border-radius: 8-12px                                        │
│     │   • Box-shadow: 0 2px 8px rgba(0,0,0,0.1)                       │
│     │   • Button hover: Darken by 10%                                  │
│     │   • Input focus: Border #2AAFF5, outline none                   │
│     └─ Responsive:                                                      │
│         • Mobile-first approach (< 768px)                               │
│         • Breakpoints: sm(640), md(768), lg(1024), xl(1280)            │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          USER FLOW DIAGRAM                                │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  USER PATH:                                                              │
│  ┌─────────┐    ┌──────────┐    ┌────────┐    ┌─────────┐             │
│  │ Landing │───▶│Registration├───▶│  Quiz  │───▶│ Results │             │
│  │  Page   │    │   Form     │    │18 Q's  │    │  Page   │             │
│  └─────────┘    └──────────┘    └────────┘    └─────────┘             │
│       │                                              │                   │
│       │                                              │                   │
│       └──────────────────────────────────────────────┘                   │
│                    [Retake Quiz - up to 3x]                              │
│                                                                          │
│  ADMIN PATH:                                                             │
│  ┌───────┐    ┌───────────┐    ┌───────────┐                           │
│  │ Login │───▶│ Dashboard │───▶│ View/Export│                           │
│  │ Page  │    │ Analytics │    │Submissions │                           │
│  └───────┘    └───────────┘    └───────────┘                           │
│                     │                                                    │
│                     └──[Logout]──▶ Back to Login                        │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          DATA FLOW                                        │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  QUIZ SUBMISSION FLOW:                                                   │
│                                                                          │
│  User Submits Quiz                                                       │
│       ↓                                                                  │
│  POST /api/quiz/submit                                                   │
│       ↓                                                                  │
│  ┌─────────────────────────────────────────────┐                        │
│  │ 1. Validate required fields                 │                        │
│  │ 2. Calculate score (correct/18)             │                        │
│  │ 3. Calculate percentage                     │                        │
│  │ 4. Determine tier based on thresholds       │                        │
│  │ 5. Calculate category breakdown (4 cats)    │                        │
│  │ 6. Check attempt number (1-3)               │                        │
│  │ 7. Save to Vercel Postgres                  │                        │
│  │ 8. Send email to ikhmal@agtgenetics.com     │                        │
│  │ 9. Return submissionId                      │                        │
│  └─────────────────────────────────────────────┘                        │
│       ↓                                                                  │
│  Redirect to /results/[submissionId]                                     │
│       ↓                                                                  │
│  ┌─────────────────────────────────────────────┐                        │
│  │ 1. Fetch submission details                 │                        │
│  │ 2. Calculate average score (all users)      │                        │
│  │ 3. Calculate user ranking                   │                        │
│  │ 4. Fetch user's historical attempts         │                        │
│  │ 5. Generate recommendations                 │                        │
│  │ 6. Display comprehensive results            │                        │
│  └─────────────────────────────────────────────┘                        │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          TECH STACK SUMMARY                               │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  Framework:     Next.js 14+ (App Router)                                 │
│  Language:      TypeScript                                               │
│  Styling:       Tailwind CSS                                             │
│  Database:      Vercel Postgres (SQL)                                    │
│  Charts:        Recharts (for radar/line charts)                         │
│  Email:         Resend (100 emails/day free)                             │
│  Auth:          HTTP-only cookies + middleware                           │
│  Deployment:    Vercel (zero-config)                                     │
│  Version Control: Git + GitHub                                           │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          KEY FEATURES CHECKLIST                           │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  QUIZ FEATURES:                                                          │
│  ✅ 18 multiple-choice questions (word-for-word from PDF)                │
│  ✅ Multi-step UI (1 question per page)                                  │
│  ✅ Progress bar visual indicator                                        │
│  ✅ Previous/Next navigation                                             │
│  ✅ 5 required registration fields                                       │
│  ✅ No time limit                                                        │
│  ✅ 3 attempts allowed per user                                          │
│  ✅ Can go back to change answers                                        │
│  ✅ Must complete in one session                                         │
│                                                                          │
│  RESULTS FEATURES:                                                       │
│  ✅ Overall score display                                                │
│  ✅ Tier badge (4 tiers)                                                 │
│  ✅ Radar chart (4 categories)                                           │
│  ✅ Question-by-question review                                          │
│  ✅ Comparison with average score                                        │
│  ✅ Personalized recommendations                                         │
│  ✅ Historical performance chart                                         │
│  ✅ Leaderboard ranking                                                  │
│                                                                          │
│  ADMIN FEATURES:                                                         │
│  ✅ Secure login (AGT_BD / AGT248)                                       │
│  ✅ 8-hour session duration                                              │
│  ✅ 4 analytics cards                                                    │
│  ✅ Submissions table (sortable)                                         │
│  ✅ Filters (date, company, tier, search)                                │
│  ✅ Pagination (10 per page)                                             │
│  ✅ Export to CSV                                                        │
│  ✅ Logout functionality                                                 │
│                                                                          │
│  EMAIL NOTIFICATION:                                                     │
│  ✅ Send to ikhmal@agtgenetics.com on submission                         │
│                                                                          │
│  MOBILE:                                                                 │
│  ✅ Mobile-first responsive design                                       │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘

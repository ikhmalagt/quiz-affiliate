import { pgTable, text, serial, integer, boolean, timestamp, jsonb, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const submissions = pgTable("submissions", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  company: text("company").notNull(),
  position: text("position").notNull(),
  answers: jsonb("answers").notNull(), // Array of { questionId: number, selected: string, correct: boolean }
  score: integer("score").notNull(),
  percentage: decimal("percentage", { precision: 5, scale: 2 }).notNull(),
  tier: text("tier").notNull(),
  categoryScores: jsonb("category_scores").notNull(), // Object { [category]: { correct: number, total: number } }
  attemptNumber: integer("attempt_number").notNull()
});

export const insertSubmissionSchema = createInsertSchema(submissions).omit({ 
  id: true, 
  timestamp: true,
});

// Input schema for the quiz submission API (frontend sends this)
export const quizSubmissionSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email"),
  phone: z.string().min(1, "Phone is required"),
  company: z.string().min(1, "Company is required"),
  position: z.string().min(1, "Position is required"),
  answers: z.array(z.object({
    questionId: z.number(),
    selected: z.string()
  })).min(18, "All 18 questions must be answered")
});

export type Submission = typeof submissions.$inferSelect;
export type InsertSubmission = z.infer<typeof insertSubmissionSchema>;
export type QuizSubmission = z.infer<typeof quizSubmissionSchema>;

export interface CategoryScore {
  correct: number;
  total: number;
}

export interface AnswerResult {
  questionId: number;
  selected: string;
  correct: boolean;
}

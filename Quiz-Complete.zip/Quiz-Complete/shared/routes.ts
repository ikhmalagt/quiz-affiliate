import { z } from 'zod';
import { quizSubmissionSchema, submissions } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  quiz: {
    submit: {
      method: 'POST' as const,
      path: '/api/quiz/submit',
      input: quizSubmissionSchema,
      responses: {
        201: z.object({
          id: z.number(),
          tier: z.string(),
          score: z.number(),
          percentage: z.string(), // Decimal returns as string
        }),
        400: errorSchemas.validation,
      },
    },
  },
  admin: {
    login: {
      method: 'POST' as const,
      path: '/api/admin/login',
      input: z.object({
        username: z.string(),
        password: z.string(),
      }),
      responses: {
        200: z.object({ success: z.boolean() }),
        401: errorSchemas.unauthorized,
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/admin/logout',
      responses: {
        200: z.object({ success: z.boolean() }),
      },
    },
    checkAuth: {
      method: 'GET' as const,
      path: '/api/admin/check-auth',
      responses: {
        200: z.object({ authenticated: z.boolean() }),
      },
    }
  },
  submissions: {
    list: {
      method: 'GET' as const,
      path: '/api/submissions',
      input: z.object({
        search: z.string().optional(),
        tier: z.string().optional(),
        company: z.string().optional(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof submissions.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/submissions/:id',
      responses: {
        200: z.custom<typeof submissions.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
  },
  analytics: {
    get: {
      method: 'GET' as const,
      path: '/api/analytics',
      responses: {
        200: z.object({
          totalSubmissions: z.number(),
          averageScore: z.number(),
          passRate: z.number(),
          mostMissedQuestionId: z.number().optional(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

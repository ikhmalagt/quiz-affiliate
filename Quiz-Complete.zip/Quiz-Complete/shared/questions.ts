export interface Question {
  id: number;
  category: string;
  question: string;
  options: string[];
  correctAnswer: string; // "A", "B", "C", "D", "E"
}

export const questions: Question[] = [
  {
    id: 1,
    category: "Product Knowledge",
    question: "What is the core business or brand identity of Absolute Genetic Technologies (AGT), as primarily emphasized throughout the materials?",
    options: [
      "A. A general technology firm specializing in bioinformatics analysis and data security compliance.",
      "B. A provider of specialized, science-backed, Asian-tailored DNA tests primarily focused on improving early childhood development (talent, nutrition, health, career) and secondarily offering wellness/career DNA tests for everyone.",
      "C. An internationally accredited laboratory based in Singapore dedicated solely to DNA extraction and genotyping procedures.",
      "D. A consultation service that helps customers save money by avoiding unnecessary spending on ineffective supplements and diets."
    ],
    correctAnswer: "B"
  },
  {
    id: 2,
    category: "Product Knowledge",
    question: "What's not included inside the AGT DNA Test Kit?",
    options: [
      "A. Greeting Card",
      "B. Gloves & facemask",
      "C. Registration Guide",
      "D. Buccal Swab",
      "E. Biohazard Ziplock Bag"
    ],
    correctAnswer: "B"
  },
  {
    id: 3,
    category: "Product Knowledge",
    question: "The Decode Talent DNA Test [Comprehensive] unlocks children's potential by analyzing a total of how many personal traits?",
    options: [
      "A. 26 nutritional traits",
      "B. 42 health risk traits",
      "C. 50 personal traits",
      "D. 15 career development traits"
    ],
    correctAnswer: "C"
  },
  {
    id: 4,
    category: "Product Knowledge",
    question: "Which DNA test is described as unlocking optimal nutrition with a comprehensive genetic assessment on 26 nutritional traits, focusing on areas like appetite, brain, bone, digestive, energy, eye, and emotional health?",
    options: [
      "A. Decode Talent DNA Test",
      "B. Decode Health DNA Test",
      "C. Decode Nutrition DNA Test",
      "D. Decode Career DNA Test"
    ],
    correctAnswer: "C"
  },
  {
    id: 5,
    category: "Product Knowledge",
    question: "The Decode Health DNA Test provides a comprehensive genetic analysis of up to 42 health risk traits. Of these traits, how many are specifically focused on different types of Cancers?",
    options: [
      "A. 8",
      "B. 10",
      "C. 19",
      "D. 42"
    ],
    correctAnswer: "C"
  },
  {
    id: 6,
    category: "Operations & Procedures",
    question: "According to the pitching material on nurturing sports performance, which specific gene is mentioned as holding the answer for whether a child may be naturally inclined toward Sprint Sports?",
    options: [
      "A. R577X gene",
      "B. ACTN3 gene",
      "C. Neuroticism gene",
      "D. ACTN4 gene"
    ],
    correctAnswer: "B"
  },
  {
    id: 7,
    category: "Operations & Procedures",
    question: "According to the DNA Sampling Procedures outlined in the training, what is the method utilized for the non-invasive saliva collection?",
    options: [
      "A. Blood draw collection",
      "B. Hair sample collection",
      "C. Buccal Swab Collection",
      "D. Fingerprint analysis"
    ],
    correctAnswer: "C"
  },
  {
    id: 8,
    category: "Business & Sales",
    question: "What is the crucial element an affiliate must ensure is used by their customers to guarantee that the affiliate's commission will be issued?",
    options: [
      "A. The customer must purchase the Child Development Bundle.",
      "B. The customer must use DuitNow as the payment option.",
      "C. The end-user must enter the promo code assigned to the affiliate during their purchase.",
      "D. The affiliate must register the test kit on the web app immediately after the sale."
    ],
    correctAnswer: "C"
  },
  {
    id: 9,
    category: "Business & Sales",
    question: "When is the estimated time that the commission will be issued?",
    options: [
      "A. Immediately after each sale",
      "B. By the end of each month",
      "C. By the 15th of each month",
      "D. At the start of the next month"
    ],
    correctAnswer: "C"
  },
  {
    id: 10,
    category: "Compliance & Privacy",
    question: "Which Malaysian Act is cited as the basis for keeping customer data safe in AGT's database under strict security protocols, ensuring data is not shared with third parties like insurance companies or employers?",
    options: [
      "A. Financial Services Act 2013",
      "B. Companies Act 2016",
      "C. Personal Data Protection Act 2010 (PDPA)",
      "D. Communications and Multimedia Act 1998"
    ],
    correctAnswer: "C"
  },
  {
    id: 11,
    category: "Compliance & Privacy",
    question: "At AGT, your privacy is of the utmost importance to us and we are committed to protecting the privacy of all our users. To safeguard your data, we have implemented high standards of technology and operational security except:",
    options: [
      "A. Anonymized Sample ID. Your sample receives a unique ID, keeping your information confidential and accessible only to authorized personnel.",
      "B. No Third-party Sharing. We never share, sell, or rent your data. You control how your information is used.",
      "C. Privacy by Design. Your genetic and personal data are stored separately in different, secure cloud systems following local and international standards for maximum protection.",
      "D. Affiliate Special Access. Data may be shared with affiliated companies for marketing purposes upon request."
    ],
    correctAnswer: "D"
  },
  {
    id: 12,
    category: "Business & Sales",
    question: "The Decode Career DNA Test assesses a combination of traits focusing on Big 5 Personality traits and what other factors?",
    options: [
      "A. Health risk traits",
      "B. 10 inborn aptitudes",
      "C. Overall Wellness traits",
      "D. Nutritional Needs"
    ],
    correctAnswer: "B"
  },
  {
    id: 13,
    category: "Business & Sales",
    question: "The DecodeTalent DNA Test [Basic] assesses a combination of 17 traits focusing on which area?",
    options: [
      "A. Talent & Learning Ability",
      "B. Personality & Overall Wellness",
      "C. EQ & Personality",
      "D. None of the above"
    ],
    correctAnswer: "D"
  },
  {
    id: 14,
    category: "Business & Sales",
    question: "According to the FAQs, how does the DNA test help mitigate future health risks and justify its cost as a long-term investment?",
    options: [
      "A. The test fee is fully covered by health insurance.",
      "B. The test is repeated annually to monitor changing genes.",
      "C. It is a once-in-a-lifetime test that helps customers avoid unnecessary spending on ineffective supplements, diets, or programs.",
      "D. The results automatically generate investment advice for the parents."
    ],
    correctAnswer: "C"
  },
  {
    id: 15,
    category: "Business & Sales",
    question: "How will a customer know that their child's DNA test report is ready after the 3-4 week processing period?",
    options: [
      "A. The report will be automatically mailed to their physical address.",
      "B. The report will be posted publicly on the AGT website with the child's name.",
      "C. They will receive a notification via email and a WhatsApp message when the report is ready for viewing on their account.",
      "D. The affiliate must personally call the customer once the results are published."
    ],
    correctAnswer: "C"
  },
  {
    id: 16,
    category: "Product Knowledge",
    question: "What's included in the Affiliate Starter Pack?",
    options: [
      "A. 5x DNA Test Kit only",
      "B. 3x A4 Flyers only",
      "C. 1x Bunting",
      "D. All the above"
    ],
    correctAnswer: "D"
  },
  {
    id: 17,
    category: "Operations & Procedures",
    question: "What should be avoided within 1 hour before collecting the saliva sample?",
    options: [
      "A. Eating or drinking (except plain water)",
      "B. Smoking",
      "C. Brush Teeth",
      "D. Applying lipstick",
      "E. All of the above"
    ],
    correctAnswer: "E"
  },
  {
    id: 18,
    category: "Product Knowledge",
    question: "Which of the following bundles are products of AGT? I. Child Bundle II. Wellness Bundle III. Adult Bundle IV. Baby Bundle",
    options: [
      "A. I and II",
      "B. I, II, and III",
      "C. I, III, and IV",
      "D. All of the above"
    ],
    correctAnswer: "B"
  }
];

export const TIERS = {
  EXCELLENT: { name: "Excellent", min: 16, max: 18, color: "#2D5F3F" },
  GOOD: { name: "Good", min: 14, max: 15, color: "#4A9B6B" },
  PASS: { name: "Pass", min: 12, max: 13, color: "#7BC79D" },
  NEED_IMPROVEMENT: { name: "Need Improvement", min: 0, max: 11, color: "#ffc107" }
};

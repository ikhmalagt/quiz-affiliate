import { db } from "./db";
import { submissions, type Submission, type InsertSubmission } from "@shared/schema";
import { eq, desc, sql, and, like, gte, lte } from "drizzle-orm";

export interface IStorage {
  createSubmission(submission: InsertSubmission): Promise<Submission>;
  getSubmission(id: number): Promise<Submission | undefined>;
  getSubmissions(filters?: { search?: string; tier?: string; company?: string; startDate?: string; endDate?: string }): Promise<Submission[]>;
  getUserAttempts(email: string): Promise<number>;
  getAnalytics(): Promise<{
    totalSubmissions: number;
    averageScore: number;
    passRate: number;
    mostMissedQuestionId: number | undefined;
  }>;
}

export class DatabaseStorage implements IStorage {
  async createSubmission(submission: InsertSubmission): Promise<Submission> {
    const [newSubmission] = await db.insert(submissions).values(submission).returning();
    return newSubmission;
  }

  async getSubmission(id: number): Promise<Submission | undefined> {
    const [submission] = await db.select().from(submissions).where(eq(submissions.id, id));
    return submission;
  }

  async getSubmissions(filters?: { search?: string; tier?: string; company?: string; startDate?: string; endDate?: string }): Promise<Submission[]> {
    let query = db.select().from(submissions).orderBy(desc(submissions.timestamp));
    
    const conditions = [];
    if (filters?.search) {
      conditions.push(
        sql`(
          ${submissions.name} ILIKE ${`%${filters.search}%`} OR 
          ${submissions.email} ILIKE ${`%${filters.search}%`}
        )`
      );
    }
    if (filters?.tier) {
      conditions.push(eq(submissions.tier, filters.tier));
    }
    if (filters?.company) {
      conditions.push(eq(submissions.company, filters.company));
    }
    if (filters?.startDate) {
      conditions.push(gte(submissions.timestamp, new Date(filters.startDate)));
    }
    if (filters?.endDate) {
      conditions.push(lte(submissions.timestamp, new Date(filters.endDate)));
    }

    if (conditions.length > 0) {
      // @ts-ignore
      query = query.where(and(...conditions));
    }

    const results = await query;
    return results;
  }

  async getUserAttempts(email: string): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)` })
      .from(submissions)
      .where(eq(submissions.email, email));
    return Number(result.count);
  }

  async getAnalytics(): Promise<{
    totalSubmissions: number;
    averageScore: number;
    passRate: number;
    mostMissedQuestionId: number | undefined;
  }> {
    const allSubmissions = await db.select().from(submissions);
    const total = allSubmissions.length;
    
    if (total === 0) {
      return { totalSubmissions: 0, averageScore: 0, passRate: 0, mostMissedQuestionId: undefined };
    }

    const avgScore = allSubmissions.reduce((acc, curr) => acc + Number(curr.score), 0) / total;
    const passed = allSubmissions.filter(s => Number(s.score) >= 12).length; // Pass is 12+ (from TIERS)
    
    // Calculate most missed question
    const questionMisses = new Map<number, number>();
    
    allSubmissions.forEach(sub => {
      const answers = sub.answers as Array<{ questionId: number; correct: boolean }>;
      answers.forEach(ans => {
        if (!ans.correct) {
          questionMisses.set(ans.questionId, (questionMisses.get(ans.questionId) || 0) + 1);
        }
      });
    });

    let mostMissedId = undefined;
    let maxMisses = -1;
    for (const [qid, misses] of Array.from(questionMisses.entries())) {
      if (misses > maxMisses) {
        maxMisses = misses;
        mostMissedId = qid;
      }
    }

    return {
      totalSubmissions: total,
      averageScore: avgScore,
      passRate: (passed / total) * 100,
      mostMissedQuestionId: mostMissedId
    };
  }
}

export const storage = new DatabaseStorage();

import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { questions, TIERS } from "@shared/questions";
import { z } from "zod";
import session from "express-session";
import MemoryStore from "memorystore";

const MemoryStoreSession = MemoryStore(session);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Setup Session for Admin Auth
  app.use(
    session({
      cookie: { maxAge: 86400000 },
      store: new MemoryStoreSession({
        checkPeriod: 86400000 // prune expired entries every 24h
      }),
      resave: false,
      saveUninitialized: false,
      secret: process.env.SESSION_SECRET || "agt-quiz-secret-key",
    })
  );

  // Middleware to check admin auth
  const requireAuth = (req: any, res: any, next: any) => {
    if (req.session.isAuthenticated) {
      next();
    } else {
      res.status(401).json({ message: "Unauthorized" });
    }
  };

  // --- Quiz Routes ---

  app.post(api.quiz.submit.path, async (req, res) => {
    try {
      const input = api.quiz.submit.input.parse(req.body);
      
      // Calculate Score
      let score = 0;
      const categoryStats: Record<string, { correct: number; total: number }> = {};
      const answerResults = [];

      // Initialize categories
      questions.forEach(q => {
        if (!categoryStats[q.category]) {
          categoryStats[q.category] = { correct: 0, total: 0 };
        }
        categoryStats[q.category].total++;
      });

      for (const ans of input.answers) {
        const question = questions.find(q => q.id === ans.questionId);
        if (!question) continue;

        // The answer usually comes in as "A. Some text..." or just "A"
        // We need to extract the letter part for comparison
        const selectedLetter = ans.selected.trim().charAt(0).toUpperCase();
        const correctLetter = question.correctAnswer.trim().charAt(0).toUpperCase();
        
        const isCorrect = selectedLetter === correctLetter;
        if (isCorrect) {
          score++;
          categoryStats[question.category].correct++;
        }

        answerResults.push({
          questionId: question.id,
          selected: selectedLetter,
          correct: isCorrect
        });
      }

      const percentage = (score / 18) * 100;
      let tier = TIERS.NEED_IMPROVEMENT.name;
      if (score >= TIERS.EXCELLENT.min) tier = TIERS.EXCELLENT.name;
      else if (score >= TIERS.GOOD.min) tier = TIERS.GOOD.name;
      else if (score >= TIERS.PASS.min) tier = TIERS.PASS.name;

      const attemptNumber = (await storage.getUserAttempts(input.email)) + 1;

      // Save to DB
      const submission = await storage.createSubmission({
        ...input,
        answers: answerResults,
        score,
        percentage: percentage.toFixed(2),
        tier,
        categoryScores: categoryStats,
        attemptNumber
      });

      // TODO: Send Email via Resend if configured
      // We can add this later once the integration is confirmed.

      res.status(201).json({
        id: submission.id,
        tier,
        score,
        percentage: percentage.toFixed(2)
      });

    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // --- Admin Routes ---

  app.post(api.admin.login.path, (req, res) => {
    const { username, password } = req.body;
    // Hardcoded credentials as per prompt
    if (username === "AGT_BD" && password === "AGT248") {
      (req.session as any).isAuthenticated = true;
      res.json({ success: true });
    } else {
      res.status(401).json({ message: "Invalid credentials" });
    }
  });

  app.post(api.admin.logout.path, (req, res) => {
    (req.session as any).destroy();
    res.json({ success: true });
  });

  app.get(api.admin.checkAuth.path, (req, res) => {
    res.json({ authenticated: !!(req.session as any).isAuthenticated });
  });

  app.get(api.submissions.list.path, requireAuth, async (req, res) => {
    const { search, tier, company, startDate, endDate } = req.query as any;
    const submissions = await storage.getSubmissions({ search, tier, company, startDate, endDate });
    res.json(submissions);
  });

  app.get(api.submissions.get.path, async (req, res) => {
    // This one might need to be public for the results page if we pass ID? 
    // Or protect it? Prompt says "Results Page ... /api/submissions/[id]".
    // Usually results are semi-public or require a token. 
    // For MVP, we'll allow public access to GET by ID, but maybe we should rely on local state in frontend? 
    // But if user refreshes, we need to fetch.
    // Let's allow public access for now for simplicity, or we could require auth if it was strict.
    // Given the requirements, users see their OWN results. 
    const id = Number(req.params.id);
    const submission = await storage.getSubmission(id);
    if (!submission) {
      return res.status(404).json({ message: "Not found" });
    }
    res.json(submission);
  });

  app.get(api.analytics.get.path, requireAuth, async (req, res) => {
    const analytics = await storage.getAnalytics();
    res.json(analytics);
  });

  return httpServer;
}

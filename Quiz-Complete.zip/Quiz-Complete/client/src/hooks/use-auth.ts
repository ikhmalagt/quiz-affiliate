import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

type LoginInput = z.infer<typeof api.admin.login.input>;

export function useAdminAuth() {
  return useQuery({
    queryKey: ["auth-check"],
    queryFn: async () => {
      const res = await fetch(api.admin.checkAuth.path, { credentials: "include" });
      if (!res.ok) return { authenticated: false };
      return api.admin.checkAuth.responses[200].parse(await res.json());
    },
    retry: false,
  });
}

export function useLogin() {
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (credentials: LoginInput) => {
      const res = await fetch(api.admin.login.path, {
        method: api.admin.login.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(credentials),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 401) throw new Error("Invalid username or password");
        throw new Error("Login failed");
      }

      return api.admin.login.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["auth-check"] });
      setLocation("/admin/dashboard");
      toast({ title: "Welcome back", description: "Successfully logged in to admin dashboard" });
    },
    onError: (error: Error) => {
      toast({
        title: "Login Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useLogout() {
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.admin.logout.path, {
        method: api.admin.logout.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Logout failed");
      return api.admin.logout.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.setQueryData(["auth-check"], { authenticated: false });
      setLocation("/admin");
      toast({ title: "Logged out", description: "See you next time" });
    },
  });
}

import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

export function useSubmissions(filters?: { search?: string; tier?: string; company?: string }) {
  const queryParams = new URLSearchParams();
  if (filters?.search) queryParams.append("search", filters.search);
  if (filters?.tier) queryParams.append("tier", filters.tier);
  if (filters?.company) queryParams.append("company", filters.company);

  const url = `${api.submissions.list.path}?${queryParams.toString()}`;

  return useQuery({
    queryKey: [api.submissions.list.path, filters],
    queryFn: async () => {
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 401) throw new Error("Unauthorized");
      if (!res.ok) throw new Error("Failed to fetch submissions");
      return api.submissions.list.responses[200].parse(await res.json());
    },
  });
}

export function useSubmission(id: number) {
  return useQuery({
    queryKey: [api.submissions.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.submissions.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (res.status === 401) throw new Error("Unauthorized");
      if (!res.ok) throw new Error("Failed to fetch submission");
      return api.submissions.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useAnalytics() {
  return useQuery({
    queryKey: [api.analytics.get.path],
    queryFn: async () => {
      const res = await fetch(api.analytics.get.path, { credentials: "include" });
      if (res.status === 401) throw new Error("Unauthorized");
      if (!res.ok) throw new Error("Failed to fetch analytics");
      return api.analytics.get.responses[200].parse(await res.json());
    },
  });
}

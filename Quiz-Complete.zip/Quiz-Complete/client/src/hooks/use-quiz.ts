import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { type QuizSubmission } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useSubmitQuiz() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: QuizSubmission) => {
      // Validate with schema first just in case
      const validated = api.quiz.submit.input.parse(data);
      
      const res = await fetch(api.quiz.submit.path, {
        method: api.quiz.submit.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to submit quiz");
      }

      return await res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { LayoutWrapper } from "@/components/layout-wrapper";
import { ArrowRight, CheckCircle2, Award, Zap } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <LayoutWrapper>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-900 pt-20 pb-32">
        {/* Abstract Background Shapes */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 opacity-20">
          <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] rounded-full bg-primary blur-[120px]" />
          <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] rounded-full bg-secondary blur-[150px]" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary font-semibold text-sm mb-6 border border-primary/20">
              Affiliate Training Program
            </span>
            <h1 className="text-4xl md:text-6xl font-display font-bold text-white mb-6 leading-tight">
              Master Personalised <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-300">
                Parenting & Family Wellness
              </span>
            </h1>
            <p className="text-lg md:text-xl text-slate-300 mb-10 max-w-2xl mx-auto leading-relaxed">
              Test your knowledge of AGT Genetics solutions for childhood development, nutrition, and health. Complete the assessment to validate your expertise.
            </p>
            
            <Link href="/quiz">
              <Button size="lg" className="h-14 px-8 text-lg rounded-full shadow-[0_0_20px_rgba(42,175,245,0.3)] hover:shadow-[0_0_30px_rgba(42,175,245,0.5)] transition-all duration-300">
                Start Training Quiz <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-white relative -mt-20 z-20 rounded-t-[3rem]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Award className="w-8 h-8 text-primary" />}
              title="Expert Knowledge"
              description="Demonstrate your understanding of DNA-based insights for family wellness."
            />
            <FeatureCard 
              icon={<Zap className="w-8 h-8 text-primary" />}
              title="Instant Feedback"
              description="Receive detailed analysis of your performance across key assessment areas."
            />
            <FeatureCard 
              icon={<CheckCircle2 className="w-8 h-8 text-primary" />}
              title="Track Performance"
              description="Monitor your improvement and achieve higher proficiency levels."
            />
          </div>
        </div>
      </section>

      {/* Visual Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1 space-y-6">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900">
              Why take the assessment?
            </h2>
            <p className="text-slate-600 text-lg leading-relaxed">
              In the field of personalised genetics, staying informed is key. The AGT Affiliate Training Quiz ensures you are equipped with the right information about our child development and wellness DNA tests.
            </p>
            <ul className="space-y-4 pt-4">
              {['Understand DNA traits', 'Identify knowledge gaps', 'Enhance affiliate proficiency', 'Provide better guidance to families'].map((item, i) => (
                <li key={i} className="flex items-center text-slate-700">
                  <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center mr-3 text-green-600">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <div className="flex-1 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-500">
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-10" />
              <img 
                src="https://images.unsplash.com/photo-1516627145497-ae6968895b74?w=800&q=80" 
                alt="Family Wellness" 
                className="w-full h-[400px] object-cover"
              />
              <div className="absolute bottom-6 left-6 right-6 z-20 text-white">
                <p className="font-display font-bold text-xl">"Unlock Potential"</p>
                <p className="text-white/80 text-sm">AGT Genetics Personalised Wellness</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </LayoutWrapper>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-lg hover:shadow-xl transition-shadow duration-300">
      <div className="w-14 h-14 rounded-xl bg-blue-50 flex items-center justify-center mb-6">
        {icon}
      </div>
      <h3 className="text-xl font-bold font-display text-slate-900 mb-3">{title}</h3>
      <p className="text-slate-600 leading-relaxed">{description}</p>
    </div>
  );
}

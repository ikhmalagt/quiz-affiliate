import { useRoute } from "wouter";
import { useSubmission } from "@/hooks/use-submissions";
import { LayoutWrapper } from "@/components/layout-wrapper";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { CategoryRadar } from "@/components/category-radar";
import { CheckCircle2, XCircle, RotateCcw, Download } from "lucide-react";
import { cn } from "@/lib/utils";
import { questions } from "@shared/questions"; // Need this to map IDs to text
import { motion } from "framer-motion";

export default function Results() {
  const [, params] = useRoute("/results/:id");
  const id = parseInt(params?.id || "0");
  const { data: submission, isLoading, error } = useSubmission(id);

  if (isLoading) {
    return (
      <LayoutWrapper>
        <div className="max-w-4xl mx-auto px-4 py-12">
          <Skeleton className="h-64 w-full rounded-2xl mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Skeleton className="h-64 rounded-xl" />
            <Skeleton className="h-64 rounded-xl" />
          </div>
        </div>
      </LayoutWrapper>
    );
  }

  if (error || !submission) {
    return (
      <LayoutWrapper>
        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
          <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-6">
            <XCircle className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Submission Not Found</h1>
          <p className="text-slate-600 mb-8">Could not retrieve the quiz results. They may not exist or you may not have permission.</p>
          <Button onClick={() => window.location.href = "/"}>Return Home</Button>
        </div>
      </LayoutWrapper>
    );
  }

  // Determine Tier Color
  const getTierColor = (tier: string) => {
    switch (tier.toLowerCase()) {
      case 'excellent': return 'text-[hsl(142,36%,27%)] bg-[hsl(142,36%,95%)] border-[hsl(142,36%,27%)]';
      case 'good': return 'text-[hsl(144,35%,45%)] bg-[hsl(144,35%,95%)] border-[hsl(144,35%,45%)]';
      case 'pass': return 'text-[hsl(147,42%,35%)] bg-[hsl(147,42%,90%)] border-[hsl(147,42%,63%)]';
      default: return 'text-amber-600 bg-amber-50 border-amber-300';
    }
  };

  const tierStyles = getTierColor(submission.tier);

  return (
    <LayoutWrapper>
      <div className="bg-slate-900 text-white pb-32 pt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-3xl font-display font-bold mb-2">Quiz Results</h1>
            <p className="text-slate-300">Completed on {new Date(submission.timestamp).toLocaleDateString()}</p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-24 pb-20 relative z-10">
        {/* Main Score Card */}
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-border mb-8">
          <div className="p-8 md:p-12 text-center">
            <div className="flex flex-col md:flex-row items-center justify-center gap-12">
              
              <div className="flex-1">
                <span className="text-sm uppercase tracking-widest text-slate-500 font-semibold mb-2 block">Total Score</span>
                <div className="relative inline-block">
                  <span className="text-7xl font-display font-bold text-slate-900">{submission.score}</span>
                  <span className="text-2xl text-slate-400 font-medium">/18</span>
                </div>
                <div className="mt-2 text-lg font-medium text-slate-600">
                  {submission.percentage}% Accuracy
                </div>
              </div>

              <div className="w-px h-24 bg-slate-100 hidden md:block" />

              <div className="flex-1 flex flex-col items-center">
                <span className="text-sm uppercase tracking-widest text-slate-500 font-semibold mb-4 block">Achieved Tier</span>
                <div className={cn("px-8 py-3 rounded-full border-2 text-xl font-bold uppercase tracking-wide", tierStyles)}>
                  {submission.tier}
                </div>
              </div>

            </div>
          </div>
          
          <div className="bg-slate-50 px-8 py-6 border-t border-slate-100 flex justify-center gap-4">
            <Button onClick={() => window.location.href = "/quiz"} variant="outline" className="gap-2">
              <RotateCcw className="w-4 h-4" /> Retake Quiz
            </Button>
            {/* Download functionality would ideally generate a PDF */}
            <Button className="gap-2 btn-primary" onClick={() => window.print()}>
              <Download className="w-4 h-4" /> Download Summary
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Performance Chart */}
          <div className="lg:col-span-1 bg-white rounded-2xl shadow-lg border border-border p-6">
            <h3 className="text-lg font-bold font-display text-slate-900 mb-6">Category Breakdown</h3>
            <CategoryRadar data={submission.categoryScores as any} />
          </div>

          {/* Question Review */}
          <div className="lg:col-span-2 bg-white rounded-2xl shadow-lg border border-border p-6">
            <h3 className="text-lg font-bold font-display text-slate-900 mb-6">Detailed Review</h3>
            <div className="space-y-6">
              {(submission.answers as any[]).map((ans, idx) => {
                const q = questions.find(q => q.id === ans.questionId);
                if (!q) return null;
                
                return (
                  <div key={idx} className="flex gap-4 p-4 rounded-xl border border-slate-100 hover:bg-slate-50 transition-colors">
                    <div className="flex-shrink-0 mt-1">
                      {ans.correct ? (
                        <CheckCircle2 className="w-6 h-6 text-green-500" />
                      ) : (
                        <XCircle className="w-6 h-6 text-red-400" />
                      )}
                    </div>
                    <div>
                      <h4 className="font-medium text-slate-900 mb-1">
                        <span className="text-slate-400 mr-2 text-sm">Q{idx + 1}</span>
                        {q.question}
                      </h4>
                      <p className={cn("text-sm", ans.correct ? "text-green-700" : "text-red-600")}>
                        Selected: <span className="font-semibold">{ans.selected}</span>
                      </p>
                      {!ans.correct && (
                        <p className="text-sm text-green-700 mt-1">
                          Correct Answer: <span className="font-semibold">{q.correctAnswer}</span>
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </LayoutWrapper>
  );
}

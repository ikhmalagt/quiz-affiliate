import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAdminAuth, useLogout } from "@/hooks/use-auth";
import { useSubmissions, useAnalytics } from "@/hooks/use-submissions";
import { LayoutWrapper } from "@/components/layout-wrapper";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, LogOut, Search, Users, Trophy, Target, Eye } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { questions } from "@shared/questions";
import { cn } from "@/lib/utils";

export default function AdminDashboard() {
  const [location, setLocation] = useLocation();
  const { data: auth, isLoading: authLoading } = useAdminAuth();
  const logout = useLogout();
  
  const [filters, setFilters] = useState({ search: "", tier: "all", company: "" });
  const [debouncedSearch, setDebouncedSearch] = useState("");

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(filters.search), 500);
    return () => clearTimeout(timer);
  }, [filters.search]);

  const { data: submissions, isLoading: subsLoading } = useSubmissions({
    search: debouncedSearch,
    tier: filters.tier === "all" ? undefined : filters.tier,
    company: filters.company
  });

  const { data: analytics, isLoading: analyticsLoading } = useAnalytics();

  useEffect(() => {
    if (!authLoading && !auth?.authenticated) {
      setLocation("/admin");
    }
  }, [auth, authLoading, setLocation]);

  if (authLoading || !auth?.authenticated) return null;

  return (
    <LayoutWrapper>
      <div className="bg-white border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-xl font-display font-bold text-slate-800">Admin Dashboard</h1>
          <Button variant="ghost" size="sm" onClick={() => logout.mutate()} className="text-slate-500 hover:text-destructive">
            <LogOut className="w-4 h-4 mr-2" /> Logout
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Analytics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatsCard 
            title="Total Submissions" 
            value={analytics?.totalSubmissions ?? 0} 
            icon={<Users className="w-5 h-5 text-blue-500" />} 
          />
          <StatsCard 
            title="Average Score" 
            value={`${analytics?.averageScore ?? 0}/18`} 
            icon={<Trophy className="w-5 h-5 text-amber-500" />} 
          />
          <StatsCard 
            title="Pass Rate" 
            value={`${analytics?.passRate ?? 0}%`} 
            icon={<Target className="w-5 h-5 text-green-500" />} 
          />
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 bg-white p-4 rounded-xl border border-border shadow-sm">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Search by name or email..." 
              className="pl-9"
              value={filters.search}
              onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
            />
          </div>
          <div className="w-full md:w-48">
            <Select 
              value={filters.tier} 
              onValueChange={(val) => setFilters(prev => ({ ...prev, tier: val }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Filter by Tier" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tiers</SelectItem>
                <SelectItem value="Excellent">Excellent</SelectItem>
                <SelectItem value="Good">Good</SelectItem>
                <SelectItem value="Pass">Pass</SelectItem>
                <SelectItem value="Needs Improvement">Needs Improvement</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Results Table */}
        <Card className="shadow-lg border-border/50 overflow-hidden">
          <CardHeader className="bg-slate-50 border-b border-border/50">
            <CardTitle>Recent Submissions</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {subsLoading ? (
              <div className="p-12 flex justify-center text-slate-400">
                <Loader2 className="w-8 h-8 animate-spin" />
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Participant</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Tier</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {submissions?.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center h-24 text-slate-500">
                        No submissions found matching your filters.
                      </TableCell>
                    </TableRow>
                  ) : (
                    submissions?.map((sub) => (
                      <TableRow key={sub.id} className="hover:bg-slate-50/50">
                        <TableCell className="text-slate-500 font-medium text-xs">
                          {new Date(sub.timestamp).toLocaleDateString()}
                          <div className="text-[10px]">{new Date(sub.timestamp).toLocaleTimeString()}</div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium text-slate-900">{sub.name}</div>
                          <div className="text-xs text-slate-500">{sub.email}</div>
                        </TableCell>
                        <TableCell className="text-slate-600">{sub.company}</TableCell>
                        <TableCell>
                          <span className="font-mono font-semibold">{sub.score}</span>
                          <span className="text-slate-400 text-xs">/18</span>
                        </TableCell>
                        <TableCell>
                          <Badge tier={sub.tier} />
                        </TableCell>
                        <TableCell className="text-right">
                          <SubmissionDetailsDialog submission={sub} />
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </LayoutWrapper>
  );
}

function StatsCard({ title, value, icon }: { title: string, value: string | number, icon: React.ReactNode }) {
  return (
    <Card className="shadow-sm border-border/50">
      <CardContent className="p-6 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-slate-500 mb-1">{title}</p>
          <p className="text-2xl font-bold text-slate-900">{value}</p>
        </div>
        <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center border border-slate-100">
          {icon}
        </div>
      </CardContent>
    </Card>
  );
}

function Badge({ tier }: { tier: string }) {
  const styles = {
    'Excellent': 'bg-green-100 text-green-700 border-green-200',
    'Good': 'bg-blue-100 text-blue-700 border-blue-200',
    'Pass': 'bg-amber-100 text-amber-700 border-amber-200',
    'Needs Improvement': 'bg-red-100 text-red-700 border-red-200',
  };
  
  const className = styles[tier as keyof typeof styles] || 'bg-slate-100 text-slate-700';

  return (
    <span className={cn("px-2.5 py-0.5 rounded-full text-xs font-semibold border", className)}>
      {tier}
    </span>
  );
}

function SubmissionDetailsDialog({ submission }: { submission: any }) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
          <Eye className="w-4 h-4 text-slate-500" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Submission Details</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase">Participant</label>
            <p className="font-medium">{submission.name}</p>
            <p className="text-sm text-slate-500">{submission.email}</p>
            <p className="text-sm text-slate-500">{submission.phone}</p>
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase">Organization</label>
            <p className="font-medium">{submission.company}</p>
            <p className="text-sm text-slate-500">{submission.position}</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <h4 className="font-semibold text-slate-900 pb-2 border-b">Responses</h4>
          {(submission.answers as any[]).map((ans, idx) => {
             const q = questions.find(q => q.id === ans.questionId);
             if (!q) return null;
             return (
               <div key={idx} className={cn("p-3 rounded-lg text-sm border", ans.correct ? "bg-green-50 border-green-100" : "bg-red-50 border-red-100")}>
                 <p className="font-medium mb-1 text-slate-800">Q{idx+1}: {q.question}</p>
                 <div className="flex justify-between">
                   <span>Selected: {ans.selected}</span>
                   {!ans.correct && <span className="text-green-600 font-medium">Correct: {q.correctAnswer}</span>}
                 </div>
               </div>
             )
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}

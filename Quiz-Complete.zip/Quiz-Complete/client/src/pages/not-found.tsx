import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";
import { LayoutWrapper } from "@/components/layout-wrapper";

export default function NotFound() {
  return (
    <LayoutWrapper>
      <div className="min-h-[80vh] w-full flex items-center justify-center bg-slate-50">
        <Card className="w-full max-w-md mx-4 shadow-xl border-border/50">
          <CardContent className="pt-6 text-center space-y-6">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="h-8 w-8 text-orange-600" />
              </div>
            </div>
            
            <div className="space-y-2">
              <h1 className="text-3xl font-display font-bold text-slate-900">404 Page Not Found</h1>
              <p className="text-slate-600 text-sm md:text-base leading-relaxed">
                The page you are looking for doesn't exist or has been moved.
              </p>
            </div>

            <Link href="/">
              <Button className="w-full btn-primary h-12 text-base">
                Return Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </LayoutWrapper>
  );
}

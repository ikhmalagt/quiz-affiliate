import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { LayoutWrapper } from "@/components/layout-wrapper";
import { QuizQuestion } from "@/components/quiz-question";
import { useSubmitQuiz } from "@/hooks/use-quiz";
import { Progress } from "@/components/ui/progress";
import { Loader2, ChevronRight, ChevronLeft, Send } from "lucide-react";
import { questions } from "@shared/questions"; // Assuming this exists or will be created
import { motion, AnimatePresence } from "framer-motion";

// Schema for step 1 (Registration)
const registrationSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Phone number must be at least 10 digits"),
  company: z.string().min(2, "Company name is required"),
  position: z.string().min(2, "Position is required"),
});

type RegistrationData = z.infer<typeof registrationSchema>;

export default function Quiz() {
  const [step, setStep] = useState(0); // 0 = registration, 1-18 = questions
  const [userData, setUserData] = useState<RegistrationData | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [, setLocation] = useLocation();
  const submitQuiz = useSubmitQuiz();

  const form = useForm<RegistrationData>({
    resolver: zodResolver(registrationSchema),
  });

  const onRegister = (data: RegistrationData) => {
    setUserData(data);
    setStep(1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAnswer = (questionId: number, answer: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const nextStep = () => {
    if (step < questions.length) {
      setStep(prev => prev + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const prevStep = () => {
    if (step > 1) {
      setStep(prev => prev - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const finishQuiz = async () => {
    if (!userData) return;

    // Transform answers object to array format expected by API
    const answersArray = Object.entries(answers).map(([qId, selected]) => ({
      questionId: parseInt(qId),
      selected
    }));

    try {
      const result = await submitQuiz.mutateAsync({
        ...userData,
        answers: answersArray
      });
      setLocation(`/results/${result.id}`);
    } catch (error) {
      console.error(error);
    }
  };

  // Calculate progress
  const progress = step === 0 ? 0 : Math.round(((step - 1) / questions.length) * 100);
  const currentQuestion = step > 0 ? questions[step - 1] : null;
  const isLastQuestion = step === questions.length;
  const canProceed = step > 0 && !!answers[currentQuestion!.id];

  return (
    <LayoutWrapper>
      <div className="max-w-3xl mx-auto px-4 py-12 min-h-[80vh] flex flex-col justify-center">
        
        {/* Progress Bar */}
        {step > 0 && (
          <div className="mb-8 space-y-2">
            <div className="flex justify-between text-sm font-medium text-slate-500">
              <span>Question {step} of {questions.length}</span>
              <span>{progress}% Completed</span>
            </div>
            <Progress value={progress} className="h-2 bg-slate-100" />
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-xl border border-border/50 p-6 md:p-10 relative overflow-hidden">
          {/* Decorative background blob */}
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
          
          <AnimatePresence mode="wait">
            {step === 0 ? (
              <motion.div
                key="registration"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <div className="mb-8">
                  <h1 className="text-3xl font-display font-bold text-slate-900 mb-2">Participant Registration</h1>
                  <p className="text-slate-600">Please provide your details to begin the certification quiz.</p>
                </div>

                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onRegister)} className="space-y-5">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" className="h-12 bg-slate-50 border-slate-200 focus:bg-white transition-colors" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="john@company.com" className="h-12 bg-slate-50 border-slate-200 focus:bg-white transition-colors" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="+1 (555) 000-0000" className="h-12 bg-slate-50 border-slate-200 focus:bg-white transition-colors" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <FormField
                        control={form.control}
                        name="company"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Company</FormLabel>
                            <FormControl>
                              <Input placeholder="AGT Affiliate Inc." className="h-12 bg-slate-50 border-slate-200 focus:bg-white transition-colors" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="position"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Position</FormLabel>
                            <FormControl>
                              <Input placeholder="Sales Representative" className="h-12 bg-slate-50 border-slate-200 focus:bg-white transition-colors" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <Button type="submit" size="lg" className="w-full mt-6 h-12 text-lg font-medium btn-primary">
                      Start Quiz <ChevronRight className="ml-2 w-5 h-5" />
                    </Button>
                  </form>
                </Form>
              </motion.div>
            ) : (
              <motion.div
                key={`question-${step}`}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="min-h-[400px] flex flex-col"
              >
                {currentQuestion && (
                  <>
                    <div className="flex-grow">
                      <QuizQuestion 
                        id={step}
                        question={currentQuestion.question}
                        options={currentQuestion.options}
                        selectedOption={answers[currentQuestion.id]}
                        onSelect={(option) => handleAnswer(currentQuestion.id, option)}
                      />
                    </div>

                    <div className="flex justify-between items-center mt-10 pt-6 border-t border-slate-100">
                      <Button 
                        variant="ghost" 
                        onClick={prevStep}
                        disabled={step === 1}
                        className="text-slate-500 hover:text-slate-900"
                      >
                        <ChevronLeft className="mr-2 w-4 h-4" /> Previous
                      </Button>

                      {isLastQuestion ? (
                        <Button 
                          onClick={finishQuiz} 
                          disabled={!canProceed || submitQuiz.isPending}
                          className="btn-primary min-w-[140px]"
                        >
                          {submitQuiz.isPending ? (
                            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting...</>
                          ) : (
                            <><Send className="mr-2 h-4 w-4" /> Submit Quiz</>
                          )}
                        </Button>
                      ) : (
                        <Button 
                          onClick={nextStep} 
                          disabled={!canProceed}
                          className="btn-primary min-w-[140px]"
                        >
                          Next Question <ChevronRight className="ml-2 h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </LayoutWrapper>
  );
}

import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  Tooltip
} from 'recharts';

interface CategoryScore {
  correct: number;
  total: number;
}

interface Props {
  data: Record<string, CategoryScore>;
}

export function CategoryRadar({ data }: Props) {
  const chartData = Object.entries(data).map(([key, value]) => ({
    subject: key,
    A: (value.correct / value.total) * 100,
    fullMark: 100,
  }));

  return (
    <div className="w-full h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
          <PolarGrid stroke="#e2e8f0" />
          <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 12 }} />
          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
          <Radar
            name="Performance"
            dataKey="A"
            stroke="#2AAFF5"
            strokeWidth={2}
            fill="#2AAFF5"
            fillOpacity={0.3}
          />
          <Tooltip 
            formatter={(value: number) => [`${Math.round(value)}%`, 'Score']}
            contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

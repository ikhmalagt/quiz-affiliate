import { motion } from "framer-motion";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

interface QuestionProps {
  id: number;
  question: string;
  options: string[];
  selectedOption?: string;
  onSelect: (option: string) => void;
}

export function QuizQuestion({ id, question, options, selectedOption, onSelect }: QuestionProps) {
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <span className="text-sm font-semibold text-primary uppercase tracking-wider mb-2 block">Question {id}</span>
        <h2 className="text-2xl font-display font-bold text-slate-800 leading-tight">
          {question}
        </h2>
      </motion.div>

      <RadioGroup value={selectedOption} onValueChange={onSelect} className="space-y-3">
        {options.map((option, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
          >
            <div
              className={cn(
                "flex items-center space-x-3 border rounded-xl p-4 cursor-pointer transition-all duration-200 hover:shadow-md",
                selectedOption === option
                  ? "border-primary bg-primary/5 shadow-md shadow-primary/10"
                  : "border-border bg-white hover:border-primary/50"
              )}
              onClick={() => onSelect(option)}
            >
              <RadioGroupItem value={option} id={`option-${idx}`} className="text-primary" />
              <Label htmlFor={`option-${idx}`} className="flex-grow cursor-pointer font-medium text-slate-700">
                {option}
              </Label>
            </div>
          </motion.div>
        ))}
      </RadioGroup>
    </div>
  );
}

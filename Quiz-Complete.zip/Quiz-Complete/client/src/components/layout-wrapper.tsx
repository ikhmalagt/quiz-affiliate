import { ReactNode } from "react";
import { Link } from "wouter";
import agtLogo from "@assets/AGT_LOGO_1767378442864.png";

export function LayoutWrapper({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <header className="bg-white border-b border-border/50 sticky top-0 z-50 backdrop-blur-sm bg-white/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group cursor-pointer">
            <img src={agtLogo} alt="AGT Logo" className="h-10 w-auto" />
            <div className="flex flex-col -space-y-1">
              <span className="text-[10px] uppercase tracking-[0.2em] text-primary font-bold">
                Affiliate Training
              </span>
            </div>
          </Link>
          <div className="flex items-center gap-4">
             {/* Add nav items here if needed later */}
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="bg-slate-900 text-slate-400 py-12 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-white font-display font-bold text-lg mb-4">AGT Genetics</h3>
            <p className="text-sm leading-relaxed max-w-xs">
              Empowering affiliates with knowledge to nurture nature and grow sustainable futures.
            </p>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Resources</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="https://www.agtgenetics.com/faq_list" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">FAQ</a></li>
              <li><a href="https://www.agtgenetics.com/term-of-service" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">Terms of Service</a></li>
              <li><a href="https://www.agtgenetics.com/privacy" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">Privacy Policy</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-sm">
              <li>info@agtgenetics.com</li>
              <li><a href="https://api.whatsapp.com/send?phone=60183687582" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">WhatsApp Support</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left text-xs">
          <div>© {new Date().getFullYear()} AGT Genetics. All rights reserved.</div>
          <div className="flex gap-4">
            <Link href="/admin" className="hover:text-primary transition-colors">Admin Login</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

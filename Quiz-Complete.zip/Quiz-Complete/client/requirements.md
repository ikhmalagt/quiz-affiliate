## Packages
framer-motion | Page transitions and UI animations
recharts | Radar chart for results visualization
lucide-react | Icons for UI elements
zod | Schema validation
clsx | Class name utility
tailwind-merge | Class merging utility
date-fns | Date formatting

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Montserrat", "sans-serif"],
}
